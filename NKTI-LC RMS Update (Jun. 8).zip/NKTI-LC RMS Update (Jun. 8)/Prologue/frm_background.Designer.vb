﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_background
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.pcbx_background = New System.Windows.Forms.PictureBox()
        CType(Me.pcbx_background, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_title
        '
        Me.lbl_title.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(254, Byte), Integer))
        Me.lbl_title.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lbl_title.Image = Global.Prologue.My.Resources.Resources.titlebar
        Me.lbl_title.ImageAlign = System.Drawing.ContentAlignment.TopRight
        Me.lbl_title.Location = New System.Drawing.Point(12, 4)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(846, 45)
        Me.lbl_title.TabIndex = 2
        Me.lbl_title.Text = "NKTI-Liver Center Record Management System"
        Me.lbl_title.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pcbx_background
        '
        Me.pcbx_background.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pcbx_background.Image = Global.Prologue.My.Resources.Resources.background
        Me.pcbx_background.Location = New System.Drawing.Point(0, 0)
        Me.pcbx_background.Name = "pcbx_background"
        Me.pcbx_background.Size = New System.Drawing.Size(705, 364)
        Me.pcbx_background.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pcbx_background.TabIndex = 1
        Me.pcbx_background.TabStop = False
        '
        'frm_background
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(705, 364)
        Me.Controls.Add(Me.lbl_title)
        Me.Controls.Add(Me.pcbx_background)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_background"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frm_background"
        Me.TransparencyKey = System.Drawing.Color.Maroon
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.pcbx_background, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pcbx_background As System.Windows.Forms.PictureBox
    Friend WithEvents lbl_title As System.Windows.Forms.Label

End Class
