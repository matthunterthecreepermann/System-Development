﻿'Not that you need to install the MySQL connectorfor Visual Studio before you run these scripts
'Also, the WAMP with the MySQL file already uploaded
'Imported cryptography service for hashing the password (One way Encryption)
Imports System.Security.Cryptography
Public Class frm_login


    Private Sub lbl_close_Click(sender As Object, e As EventArgs) Handles lbl_close.Click
        'Close Button at the Upper-right corner
        Me.Close()
    End Sub

    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        btn_login.Enabled = False
        'establishing connection
        Connect()

        'Declare new encryption object
        Dim hashjm As New Encryption
        Dim hashsha1 As New Encryption

        'Declaration for SQL Query
        Dim sql As String

        'Assigning the SQL Query to the declared variable
        sql = "SELECT * FROM tbl_login WHERE user='" & txt_user.Text & "' AND pass='" & hashsha1.getSHA1Hash(hashjm.getJMCRYPTHash(txt_pass.Text)) & "'"

        'Attaching Command to be executed from SQL query using Connection
        With Cmd
            .Connection = Conn
            .CommandText = sql
        End With
        rd = Cmd.ExecuteReader

        'Check whether there are records appeared based on the given info. (Username & Password)
        If rd.HasRows Then
            While rd.Read
                Dim user_type = rd.GetValue(2)
                Dim user = rd.GetValue(3)
                'If there's any, will check the user-type
                If user_type = "admin" Then
                    tmr_transition.Enabled = True
                    frm_main.ss_status.Visible = False
                    frm_main.tlstrp_User.Text = "Welcome: " & user
                    wait(1)
                    frm_main.Show()
                    frm_main.Height = 30
                    tmr_transition2.Enabled = True
                    Me.Hide()
                    'wait(1)
                    btn_login.Enabled = True
                End If
            End While
        Else
            'And ofcourse, if there's nothing, this will be displayed
            MsgBox("Nothing Appears", vbExclamation + vbOKOnly, "Error")
            btn_login.Enabled = True
        End If
        'After reading, will dispose and disconnect on DB for future use.
        ReaderDispose()
        CommandDispose()
        Disconnect()
        wait(1)
        frm_main.ss_status.Visible = True
    End Sub
    'The MouseMove and MouseLeave events are only for design purpose
    Private Sub lbl_close_MouseMove(sender As Object, e As MouseEventArgs) Handles lbl_close.MouseMove
        lbl_close.BackColor = Color.White
    End Sub

    Private Sub lbl_close_MouseLeave(sender As Object, e As EventArgs) Handles lbl_close.MouseLeave
        lbl_close.BackColor = Color.DarkCyan
    End Sub

    Private Sub frm_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'This part will load the background screen
        frm_background.Show()
        txt_user.Text = ""
        txt_pass.Text = ""
        tmr_load.Enabled = True
        Me.Height = 30

        
        'This part will try to establish connection
        Try
            'Establishing Connection
            Connect()

            'if Connection state is OK then it will disconnect for future use
            If Conn.State = ConnectionState.Open Then
                Disconnect()
            End If

            'Else it will show an error message
        Catch ex As MySql.Data.MySqlClient.MySqlException

            'Message box for the error message
            If MsgBox(ex.Message + " Would you like to configure Server Connection?", vbCritical + vbYesNo, "Connection to Server Failed.") = vbYes Then
                frm_configDB.Show()
                frm_configDB.TopMost = True
                Me.TopMost = False

            Else
                'If the user don't want to Configure Connection, the form will close.
                Close()
            End If
        End Try
    End Sub

    Private Sub tmr_transition_Tick(sender As Object, e As EventArgs) Handles tmr_transition.Tick
        If Me.Height <> 30 Then
            Me.Height = Me.Height - 10
        Else
            tmr_transition.Enabled = False
        End If
    End Sub
    'This is for time delay just for the animation only
    Private Sub wait(ByVal seconds As Integer)
        For i As Integer = 0 To seconds * 100
            System.Threading.Thread.Sleep(10)
            Application.DoEvents()
        Next
    End Sub
    'Transition effect for Main form
    Private Sub tmr_transition2_Tick(sender As Object, e As EventArgs) Handles tmr_transition2.Tick
        If frm_main.Height <> 600 Then
            frm_main.Height = frm_main.Height + 10
        Else
            tmr_transition2.Enabled = False
        End If
    End Sub

    Private Sub tmr_load_Tick(sender As Object, e As EventArgs) Handles tmr_load.Tick
        If Me.Height <> 300 Then
            Me.Height = Me.Height + 10
        Else
            tmr_load.Enabled = False
        End If
    End Sub
End Class