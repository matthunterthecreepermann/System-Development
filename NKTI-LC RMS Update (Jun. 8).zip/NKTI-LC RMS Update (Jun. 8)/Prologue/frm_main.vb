﻿Imports System.IO
Public Class frm_main
    Public x As Integer = 1
    Public connslideshow As New MySql.Data.MySqlClient.MySqlConnection
    Public cmdslideshow As New MySql.Data.MySqlClient.MySqlCommand
    Public readerslideshow As MySql.Data.MySqlClient.MySqlDataReader
    Public Sub connectslideshow()
        Dim File_Name As String = "..\..\Config\Conn_String.txt"
        Dim ObjReader As New System.IO.StreamReader(File_Name)
        Dim constringslshow As String = ""

        'Assigning variable to the content of config file
        constringslshow = ObjReader.ReadToEnd

        'Assigning connection string from ConnString Variable
        connslideshow.ConnectionString = constringslshow

        'Opening Connection
        connslideshow.Open()
    End Sub

    Private Sub lbl_close_Click(sender As Object, e As EventArgs) Handles lbl_close.Click
        tmr_slideshow.Enabled = False
        Dim x As String
        x = MsgBox("Are you sure that you want to log-out?", vbExclamation + vbYesNo, "Confirmation")
        If x = vbYes Then
            tmr_slideshow.Dispose()
            readerslideshow.Dispose()
            cmdslideshow.Dispose()
            connslideshow.Close()
            ss_status.Visible = False
            tmr_transition2.Enabled = True
            wait(1)
            Me.Close()
            tmr_transition.Enabled = True
            frm_login.txt_user.Text = ""
            frm_login.txt_pass.Text = ""
            frm_login.Show()
            frm_login.txt_user.Focus()
        Else
            tmr_slideshow.Enabled = True
            Exit Sub
        End If
    End Sub

    Private Sub Label2_MouseMove(sender As Object, e As MouseEventArgs) Handles lbl_close.MouseMove
        lbl_close.BackColor = Color.White
    End Sub

    Private Sub Label2_MouseLeave(sender As Object, e As EventArgs) Handles lbl_close.MouseLeave
        lbl_close.BackColor = Color.DarkCyan
    End Sub

    Private Sub tmr_transition_Tick(sender As Object, e As EventArgs) Handles tmr_transition.Tick
        If frm_login.Height <> 300 Then
            frm_login.Height = frm_login.Height + 10
        Else
            tmr_transition.Enabled = False
        End If
    End Sub
    Private Sub wait(ByVal seconds As Integer)
        For i As Integer = 0 To seconds * 100
            System.Threading.Thread.Sleep(10)
            Application.DoEvents()
        Next
    End Sub

    Private Sub tmr_transition2_Tick(sender As Object, e As EventArgs) Handles tmr_transition2.Tick
        If Me.Height <> 30 Then
            Me.Height = Me.Height - 10
        Else
            tmr_transition2.Enabled = False
        End If
    End Sub

    Private Sub frm_main_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        pnl_registration.Visible = False
        pnl_statusrecipient.Visible = False
        pnl_statusbtns.Visible = False
    End Sub


    Private Sub btn_registration_Click(sender As Object, e As EventArgs) Handles btn_registration.Click
        tran_buttons.HideSync(pnl_main, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_registration, True, BunifuAnimatorNS.Animation.HorizSlide)
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles btn_home.Click
        tran_buttons.HideSync(pnl_registration, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_main, True, BunifuAnimatorNS.Animation.HorizSlide)
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem1.Click
        Call lbl_close_Click(sender, e)
    End Sub

    Private Sub btn_status_Click(sender As Object, e As EventArgs) Handles btn_status.Click
        tran_buttons.HideSync(pnl_main, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_statusbtns, True, BunifuAnimatorNS.Animation.HorizSlide)
    End Sub

    Private Sub pnl_status_VisibleChanged(sender As Object, e As EventArgs) Handles pnl_statusrecipient.VisibleChanged
    End Sub

    Private Sub btn_stathome_Click(sender As Object, e As EventArgs) Handles btn_stathome.Click
        tran_buttons.HideSync(pnl_statusbtns, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.HideSync(pnl_statusrecipient, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_main, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_home, True, BunifuAnimatorNS.Animation.HorizSlide)
    End Sub

    Private Sub btn_statrecipient_Click(sender As Object, e As EventArgs) Handles btn_statrecipient.Click
        'This two first lines are for transitioning buttons 
        tran_buttons.HideSync(pnl_home, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.HideSync(pnl_statusdonor, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_statusrecipient, True, BunifuAnimatorNS.Animation.HorizSlide)

        'This line is for clearing the listview object and refreshes for new items
        lstvw_status.Clear()

        lstvw_status.Columns.Add("Patient ID", 100, HorizontalAlignment.Right)
        lstvw_status.Columns.Add("Surname", 150, HorizontalAlignment.Center)
        lstvw_status.Columns.Add("First Name", 150, HorizontalAlignment.Center)
        lstvw_status.Columns.Add("Last Name", 150, HorizontalAlignment.Center)

        'Declaring variable for query on DB
        Dim query As String

        'Establishes connection
        Connect()

        'Assigning value to the query variable
        query = "SELECT * FROM tbl_records"

        'Assigning connection and query to the command object
        With Cmd
            .Connection = Conn
            .CommandText = query
        End With

        'Execute Reader
        rd = Cmd.ExecuteReader

        'If there's a content, will show some of the details
        If rd.HasRows Then
            While rd.Read
                Dim nw_item As New ListViewItem
                nw_item.Text = rd.GetValue(0)
                nw_item.SubItems.Add(rd.GetValue(1))
                nw_item.SubItems.Add(rd.GetValue(2))
                nw_item.SubItems.Add(rd.GetValue(3))
                lstvw_status.Items.Add(nw_item)
                If nw_item.Text = "10001" Then
                    nw_item.BackColor = Color.Black
                    nw_item.ForeColor = Color.White
                End If
            End While
        End If
        ReaderDispose()
        CommandDispose()
        Disconnect()
    End Sub

    Private Sub btn_recipient_Click(sender As Object, e As EventArgs) Handles btn_recipient.Click
        tmr_slideshow.Enabled = False
        frm_recipient.Show()
        Me.TopMost = False
        Me.Hide()
        frm_recipient.TopMost = True
    End Sub

    Private Sub btn_drop_Click(sender As Object, e As EventArgs) Handles btn_drop.Click
        cms_drop.Show(btn_drop, btn_drop.Width - cms_drop.Width, btn_drop.Height)
    End Sub

    Private Sub btn_donor_Click(sender As Object, e As EventArgs) Handles btn_donor.Click
        tmr_slideshow.Enabled = False
        frm_donor.Show()
        Me.TopMost = False
        Me.Hide()
        frm_donor.TopMost = True
    End Sub

    Private Sub btn_statdonor_Click(sender As Object, e As EventArgs) Handles btn_statdonor.Click
        'This two first lines are for transitioning buttons 
        tran_buttons.HideSync(pnl_home, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.HideSync(pnl_statusrecipient, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_statusdonor, True, BunifuAnimatorNS.Animation.HorizSlide)

        'This line is for clearing the listview object and refreshes for new items
        lstvw_statusdonor.Clear()

        lstvw_statusdonor.Columns.Add("Donor ID", 100, HorizontalAlignment.Right)
        lstvw_statusdonor.Columns.Add("Surname", 150, HorizontalAlignment.Center)
        lstvw_statusdonor.Columns.Add("First Name", 150, HorizontalAlignment.Center)
        lstvw_statusdonor.Columns.Add("Middle Name", 150, HorizontalAlignment.Center)

        'Declaring variable for query on DB
        Dim query As String

        'Establishes connection
        Disconnect()
        Connect()

        'Assigning value to the query variable
        query = "SELECT * FROM tbl_donor"

        'Assigning connection and query to the command object
        With Cmd
            .Connection = Conn
            .CommandText = query
        End With

        'Execute Reader
        rd = Cmd.ExecuteReader

        'If there's a content, will show some of the details
        If rd.HasRows Then
            While rd.Read
                Dim nw_item As New ListViewItem
                nw_item.Text = rd.GetValue(1)
                nw_item.SubItems.Add(rd.GetValue(2))
                nw_item.SubItems.Add(rd.GetValue(3))
                nw_item.SubItems.Add(rd.GetValue(4))
                lstvw_statusdonor.Items.Add(nw_item)
                If nw_item.Text = "10001" Then
                    nw_item.BackColor = Color.Black
                    nw_item.ForeColor = Color.White
                End If
            End While
        End If
        ReaderDispose()
        CommandDispose()
        Disconnect()
    End Sub

    Private Sub lstvw_statusdonor_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles lstvw_statusdonor.MouseDoubleClick
        frm_donordetails.Show()
    End Sub

    Private Sub pnl_home_VisibleChanged(sender As Object, e As EventArgs) Handles pnl_home.VisibleChanged
        If pnl_home.Visible = True Then
            tmr_slideshow.enabled = True
        Else
            tmr_slideshow.Enabled = False
        End If
    End Sub

    Private Sub tmr_slideshow_Tick(sender As Object, e As EventArgs) Handles tmr_slideshow.Tick
        connectslideshow()
        Dim sql As String
        sql = "SELECT * FROM tbl_slideshow WHERE entryNo = '" & x & "'"

        With cmdslideshow
            .Connection = connslideshow
            .CommandText = sql
        End With

        readerslideshow = cmdslideshow.ExecuteReader

        If readerslideshow.HasRows Then
            While readerslideshow.Read
                Dim data As Byte() = DirectCast(readerslideshow.GetValue(1), Byte())
                Dim ms As New MemoryStream(data)
                trans_slideshow.HideSync(pcbx_slideshow, False, BunifuAnimatorNS.Animation.Scale)
                trans_slideshow.HideSync(lbl_slideshow, False, BunifuAnimatorNS.Animation.VertSlide)
                pcbx_slideshow.Image = New Bitmap(ms)
                lbl_slideshow.Text = readerslideshow.GetValue(2)
                trans_slideshow.ShowSync(pcbx_slideshow, False, BunifuAnimatorNS.Animation.Scale)
                trans_slideshow.ShowSync(lbl_slideshow, False, BunifuAnimatorNS.Animation.VertSlide)
                x += 1
            End While
        Else
            x = 1
        End If
        readerslideshow.Dispose()
        cmdslideshow.Dispose()
        connslideshow.Close()
    End Sub

End Class
