﻿
Public Class frm_donordetails

    Public Sub rdonly()
        txt_surname.ReadOnly = True
        txt_firstname.ReadOnly = True
        txt_middlename.ReadOnly = True
        txt_age.ReadOnly = True
        txt_birthdate.ReadOnly = True
        rb_female.Enabled = False
        rb_male.Enabled = False
        txt_address.ReadOnly = True
        txt_donorID.ReadOnly = True
        cmb_civil.Enabled = False
        cmb_bloodtype.Enabled = False
        txt_nationality.ReadOnly = True
        txt_contactNO.ReadOnly = True
    End Sub

    Public Sub enableupdate()
        txt_surname.ReadOnly = False
        txt_firstname.ReadOnly = False
        txt_middlename.ReadOnly = False
        txt_age.ReadOnly = False
        txt_birthdate.ReadOnly = False
        rb_female.Enabled = True
        rb_male.Enabled = True
        txt_address.ReadOnly = False
        txt_donorID.ReadOnly = False
        cmb_civil.Enabled = True
        cmb_bloodtype.Enabled = True
        txt_nationality.ReadOnly = False
        txt_contactNO.ReadOnly = False
    End Sub
    Private Sub frm_donordetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call rdonly()
        Dim nwitem As ListViewItem = frm_main.lstvw_statusdonor.SelectedItems(0)
        ReaderDispose()
        CommandDispose()
        Connect()
        Dim sql As String
        sql = "SELECT * FROM tbl_donor WHERE donorID = '" & nwitem.Text & "'"
        Cmd.Dispose()
        With Cmd
            .Connection = Conn
            .CommandText = sql
        End With
        rd.Dispose()
        rd = Cmd.ExecuteReader
        rd.Read()
        txt_donorID.Text = rd.GetValue(1)
        txt_surname.Text = rd.GetValue(2)
        txt_firstname.Text = rd.GetValue(3)
        txt_middlename.Text = rd.GetValue(4)
        txt_age.Text = rd.GetValue(5)
        txt_birthdate.Text = rd.GetValue(6)
        txt_gender.Text = rd.GetValue(7)
        txt_address.Text = rd.GetValue(8)
        cmb_civil.Text = rd.GetValue(9)
        cmb_bloodtype.Text = rd.GetValue(10)
        txt_nationality.Text = rd.GetValue(11)
        txt_contactNO.Text = rd.GetValue(12)

        If txt_gender.Text = "Male" Then
            rb_male.Checked = True
        ElseIf txt_gender.Text = "Female" Then
            rb_female.Checked = True
        End If
    End Sub

    Private Sub lbl_close_Click(sender As Object, e As EventArgs) Handles lbl_close.Click
        ReaderDispose()
        CommandDispose()
        Disconnect()
        Me.Close()
    End Sub

    Private Sub lbl_close_MouseMove(sender As Object, e As EventArgs) Handles lbl_close.MouseMove
        lbl_close.BackColor = Color.White
    End Sub

    Private Sub lbl_close_MouseLeave(sender As Object, e As EventArgs) Handles lbl_close.MouseLeave
        lbl_close.BackColor = Color.DarkCyan
    End Sub
End Class