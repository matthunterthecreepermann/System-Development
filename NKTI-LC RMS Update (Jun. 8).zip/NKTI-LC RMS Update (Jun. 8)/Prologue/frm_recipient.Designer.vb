﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_recipient
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_patientprofile = New System.Windows.Forms.Label()
        Me.gb_patientname = New System.Windows.Forms.GroupBox()
        Me.lbl_middlename = New System.Windows.Forms.Label()
        Me.lbl_firstname = New System.Windows.Forms.Label()
        Me.lbl_lastname = New System.Windows.Forms.Label()
        Me.txt_middlename = New System.Windows.Forms.TextBox()
        Me.txt_firstname = New System.Windows.Forms.TextBox()
        Me.txt_surname = New System.Windows.Forms.TextBox()
        Me.gb_birthdate = New System.Windows.Forms.GroupBox()
        Me.lbl_year = New System.Windows.Forms.Label()
        Me.lbl_date = New System.Windows.Forms.Label()
        Me.lbl_month = New System.Windows.Forms.Label()
        Me.cmb_year = New System.Windows.Forms.ComboBox()
        Me.cmb_date = New System.Windows.Forms.ComboBox()
        Me.cmb_month = New System.Windows.Forms.ComboBox()
        Me.gb_age = New System.Windows.Forms.GroupBox()
        Me.txt_age = New System.Windows.Forms.TextBox()
        Me.gb_gender = New System.Windows.Forms.GroupBox()
        Me.rb_female = New System.Windows.Forms.RadioButton()
        Me.rb_male = New System.Windows.Forms.RadioButton()
        Me.gb_patientID = New System.Windows.Forms.GroupBox()
        Me.txt_patientID = New System.Windows.Forms.TextBox()
        Me.gb_hospNO = New System.Windows.Forms.GroupBox()
        Me.txt_hospitalNO = New System.Windows.Forms.TextBox()
        Me.gb_civil = New System.Windows.Forms.GroupBox()
        Me.rb_others = New System.Windows.Forms.RadioButton()
        Me.rb_widow = New System.Windows.Forms.RadioButton()
        Me.rb_married = New System.Windows.Forms.RadioButton()
        Me.rb_single = New System.Windows.Forms.RadioButton()
        Me.gb_nationality = New System.Windows.Forms.GroupBox()
        Me.txt_nationality = New System.Windows.Forms.TextBox()
        Me.gb_religion = New System.Windows.Forms.GroupBox()
        Me.txt_religion = New System.Windows.Forms.TextBox()
        Me.gb_address = New System.Windows.Forms.GroupBox()
        Me.txt_civil = New System.Windows.Forms.TextBox()
        Me.txt_address = New System.Windows.Forms.TextBox()
        Me.lbl_address = New System.Windows.Forms.Label()
        Me.gb_email = New System.Windows.Forms.GroupBox()
        Me.txt_email = New System.Windows.Forms.TextBox()
        Me.gb_contactNO = New System.Windows.Forms.GroupBox()
        Me.txt_contactNO = New System.Windows.Forms.TextBox()
        Me.gb_referred = New System.Windows.Forms.GroupBox()
        Me.txt_referred = New System.Windows.Forms.TextBox()
        Me.gb_specialization = New System.Windows.Forms.GroupBox()
        Me.txt_specialization = New System.Windows.Forms.TextBox()
        Me.gb_physician = New System.Windows.Forms.GroupBox()
        Me.txt_physician = New System.Windows.Forms.TextBox()
        Me.gb_surgeon = New System.Windows.Forms.GroupBox()
        Me.txt_surgeon = New System.Windows.Forms.TextBox()
        Me.gb_patientclass = New System.Windows.Forms.GroupBox()
        Me.rb_pay = New System.Windows.Forms.RadioButton()
        Me.rb_service = New System.Windows.Forms.RadioButton()
        Me.lbl_emergency = New System.Windows.Forms.Label()
        Me.gb_emerrelationship = New System.Windows.Forms.GroupBox()
        Me.txt_emerrelationship = New System.Windows.Forms.TextBox()
        Me.gb_emername = New System.Windows.Forms.GroupBox()
        Me.txt_emername = New System.Windows.Forms.TextBox()
        Me.gb_emercontact = New System.Windows.Forms.GroupBox()
        Me.txt_emercontact = New System.Windows.Forms.TextBox()
        Me.gb_emeraddress = New System.Windows.Forms.GroupBox()
        Me.txt_emeraddress = New System.Windows.Forms.TextBox()
        Me.lbl_employment = New System.Windows.Forms.Label()
        Me.gb_occupation = New System.Windows.Forms.GroupBox()
        Me.txt_occupation = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txt_officecontact = New System.Windows.Forms.TextBox()
        Me.gb_company = New System.Windows.Forms.GroupBox()
        Me.txt_dept = New System.Windows.Forms.TextBox()
        Me.rb_otherdept = New System.Windows.Forms.RadioButton()
        Me.rb_nktiemployee = New System.Windows.Forms.RadioButton()
        Me.gb_officeaddress = New System.Windows.Forms.GroupBox()
        Me.txt_officeaddress = New System.Windows.Forms.TextBox()
        Me.lbl_medical = New System.Windows.Forms.Label()
        Me.gb_familymed = New System.Windows.Forms.GroupBox()
        Me.cmb_familymed = New System.Windows.Forms.ComboBox()
        Me.gb_personalmed = New System.Windows.Forms.GroupBox()
        Me.cmb_personalmed = New System.Windows.Forms.ComboBox()
        Me.lbl_surgical = New System.Windows.Forms.Label()
        Me.gb_surgical = New System.Windows.Forms.GroupBox()
        Me.txt_dateperformed = New System.Windows.Forms.TextBox()
        Me.txt_surgical = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lbl_close = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.BunifuFlatButton5 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.lbl_verify = New System.Windows.Forms.Label()
        Me.chk_verify = New System.Windows.Forms.CheckBox()
        Me.btn_submit = New System.Windows.Forms.Button()
        Me.txt_gender = New System.Windows.Forms.TextBox()
        Me.txt_class = New System.Windows.Forms.TextBox()
        Me.txt_company = New System.Windows.Forms.TextBox()
        Me.gb_patientname.SuspendLayout()
        Me.gb_birthdate.SuspendLayout()
        Me.gb_age.SuspendLayout()
        Me.gb_gender.SuspendLayout()
        Me.gb_patientID.SuspendLayout()
        Me.gb_hospNO.SuspendLayout()
        Me.gb_civil.SuspendLayout()
        Me.gb_nationality.SuspendLayout()
        Me.gb_religion.SuspendLayout()
        Me.gb_address.SuspendLayout()
        Me.gb_email.SuspendLayout()
        Me.gb_contactNO.SuspendLayout()
        Me.gb_referred.SuspendLayout()
        Me.gb_specialization.SuspendLayout()
        Me.gb_physician.SuspendLayout()
        Me.gb_surgeon.SuspendLayout()
        Me.gb_patientclass.SuspendLayout()
        Me.gb_emerrelationship.SuspendLayout()
        Me.gb_emername.SuspendLayout()
        Me.gb_emercontact.SuspendLayout()
        Me.gb_emeraddress.SuspendLayout()
        Me.gb_occupation.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.gb_company.SuspendLayout()
        Me.gb_officeaddress.SuspendLayout()
        Me.gb_familymed.SuspendLayout()
        Me.gb_personalmed.SuspendLayout()
        Me.gb_surgical.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl_patientprofile
        '
        Me.lbl_patientprofile.BackColor = System.Drawing.Color.DodgerBlue
        Me.lbl_patientprofile.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_patientprofile.ForeColor = System.Drawing.Color.White
        Me.lbl_patientprofile.Location = New System.Drawing.Point(230, 62)
        Me.lbl_patientprofile.Name = "lbl_patientprofile"
        Me.lbl_patientprofile.Size = New System.Drawing.Size(518, 23)
        Me.lbl_patientprofile.TabIndex = 0
        Me.lbl_patientprofile.Text = "PATIENT PROFILE"
        Me.lbl_patientprofile.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'gb_patientname
        '
        Me.gb_patientname.Controls.Add(Me.lbl_middlename)
        Me.gb_patientname.Controls.Add(Me.lbl_firstname)
        Me.gb_patientname.Controls.Add(Me.lbl_lastname)
        Me.gb_patientname.Controls.Add(Me.txt_middlename)
        Me.gb_patientname.Controls.Add(Me.txt_firstname)
        Me.gb_patientname.Controls.Add(Me.txt_surname)
        Me.gb_patientname.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_patientname.ForeColor = System.Drawing.Color.White
        Me.gb_patientname.Location = New System.Drawing.Point(233, 88)
        Me.gb_patientname.Name = "gb_patientname"
        Me.gb_patientname.Size = New System.Drawing.Size(515, 81)
        Me.gb_patientname.TabIndex = 1
        Me.gb_patientname.TabStop = False
        Me.gb_patientname.Text = "PATIENT NAME"
        '
        'lbl_middlename
        '
        Me.lbl_middlename.AutoSize = True
        Me.lbl_middlename.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_middlename.Location = New System.Drawing.Point(377, 54)
        Me.lbl_middlename.Name = "lbl_middlename"
        Me.lbl_middlename.Size = New System.Drawing.Size(106, 19)
        Me.lbl_middlename.TabIndex = 6
        Me.lbl_middlename.Text = "Middle Name"
        '
        'lbl_firstname
        '
        Me.lbl_firstname.AutoSize = True
        Me.lbl_firstname.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_firstname.Location = New System.Drawing.Point(215, 54)
        Me.lbl_firstname.Name = "lbl_firstname"
        Me.lbl_firstname.Size = New System.Drawing.Size(88, 19)
        Me.lbl_firstname.TabIndex = 5
        Me.lbl_firstname.Text = "First Name"
        '
        'lbl_lastname
        '
        Me.lbl_lastname.AutoSize = True
        Me.lbl_lastname.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_lastname.Location = New System.Drawing.Point(44, 54)
        Me.lbl_lastname.Name = "lbl_lastname"
        Me.lbl_lastname.Size = New System.Drawing.Size(87, 19)
        Me.lbl_lastname.TabIndex = 2
        Me.lbl_lastname.Text = "Last Name"
        '
        'txt_middlename
        '
        Me.txt_middlename.Location = New System.Drawing.Point(345, 25)
        Me.txt_middlename.Name = "txt_middlename"
        Me.txt_middlename.Size = New System.Drawing.Size(164, 26)
        Me.txt_middlename.TabIndex = 4
        '
        'txt_firstname
        '
        Me.txt_firstname.Location = New System.Drawing.Point(175, 25)
        Me.txt_firstname.Name = "txt_firstname"
        Me.txt_firstname.Size = New System.Drawing.Size(164, 26)
        Me.txt_firstname.TabIndex = 3
        '
        'txt_surname
        '
        Me.txt_surname.Location = New System.Drawing.Point(6, 25)
        Me.txt_surname.Name = "txt_surname"
        Me.txt_surname.Size = New System.Drawing.Size(164, 26)
        Me.txt_surname.TabIndex = 2
        '
        'gb_birthdate
        '
        Me.gb_birthdate.Controls.Add(Me.lbl_year)
        Me.gb_birthdate.Controls.Add(Me.lbl_date)
        Me.gb_birthdate.Controls.Add(Me.lbl_month)
        Me.gb_birthdate.Controls.Add(Me.cmb_year)
        Me.gb_birthdate.Controls.Add(Me.cmb_date)
        Me.gb_birthdate.Controls.Add(Me.cmb_month)
        Me.gb_birthdate.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_birthdate.ForeColor = System.Drawing.Color.White
        Me.gb_birthdate.Location = New System.Drawing.Point(233, 175)
        Me.gb_birthdate.Name = "gb_birthdate"
        Me.gb_birthdate.Size = New System.Drawing.Size(181, 82)
        Me.gb_birthdate.TabIndex = 2
        Me.gb_birthdate.TabStop = False
        Me.gb_birthdate.Text = "BIRTHDATE"
        '
        'lbl_year
        '
        Me.lbl_year.AutoSize = True
        Me.lbl_year.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_year.Location = New System.Drawing.Point(120, 54)
        Me.lbl_year.Name = "lbl_year"
        Me.lbl_year.Size = New System.Drawing.Size(41, 19)
        Me.lbl_year.TabIndex = 5
        Me.lbl_year.Text = "yyyy"
        '
        'lbl_date
        '
        Me.lbl_date.AutoSize = True
        Me.lbl_date.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_date.Location = New System.Drawing.Point(69, 54)
        Me.lbl_date.Name = "lbl_date"
        Me.lbl_date.Size = New System.Drawing.Size(27, 19)
        Me.lbl_date.TabIndex = 4
        Me.lbl_date.Text = "dd"
        '
        'lbl_month
        '
        Me.lbl_month.AutoSize = True
        Me.lbl_month.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_month.Location = New System.Drawing.Point(12, 54)
        Me.lbl_month.Name = "lbl_month"
        Me.lbl_month.Size = New System.Drawing.Size(37, 19)
        Me.lbl_month.TabIndex = 3
        Me.lbl_month.Text = "mm"
        '
        'cmb_year
        '
        Me.cmb_year.FormattingEnabled = True
        Me.cmb_year.Location = New System.Drawing.Point(111, 25)
        Me.cmb_year.Name = "cmb_year"
        Me.cmb_year.Size = New System.Drawing.Size(62, 26)
        Me.cmb_year.TabIndex = 2
        '
        'cmb_date
        '
        Me.cmb_date.FormattingEnabled = True
        Me.cmb_date.Location = New System.Drawing.Point(59, 25)
        Me.cmb_date.Name = "cmb_date"
        Me.cmb_date.Size = New System.Drawing.Size(47, 26)
        Me.cmb_date.TabIndex = 1
        '
        'cmb_month
        '
        Me.cmb_month.FormattingEnabled = True
        Me.cmb_month.Location = New System.Drawing.Point(6, 25)
        Me.cmb_month.Name = "cmb_month"
        Me.cmb_month.Size = New System.Drawing.Size(47, 26)
        Me.cmb_month.TabIndex = 0
        '
        'gb_age
        '
        Me.gb_age.Controls.Add(Me.txt_age)
        Me.gb_age.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_age.ForeColor = System.Drawing.Color.White
        Me.gb_age.Location = New System.Drawing.Point(420, 175)
        Me.gb_age.Name = "gb_age"
        Me.gb_age.Size = New System.Drawing.Size(81, 64)
        Me.gb_age.TabIndex = 3
        Me.gb_age.TabStop = False
        Me.gb_age.Text = "AGE"
        '
        'txt_age
        '
        Me.txt_age.Location = New System.Drawing.Point(6, 25)
        Me.txt_age.Name = "txt_age"
        Me.txt_age.Size = New System.Drawing.Size(69, 26)
        Me.txt_age.TabIndex = 0
        '
        'gb_gender
        '
        Me.gb_gender.Controls.Add(Me.rb_female)
        Me.gb_gender.Controls.Add(Me.rb_male)
        Me.gb_gender.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_gender.ForeColor = System.Drawing.Color.White
        Me.gb_gender.Location = New System.Drawing.Point(507, 175)
        Me.gb_gender.Name = "gb_gender"
        Me.gb_gender.Size = New System.Drawing.Size(98, 82)
        Me.gb_gender.TabIndex = 4
        Me.gb_gender.TabStop = False
        Me.gb_gender.Text = "GENDER"
        '
        'rb_female
        '
        Me.rb_female.AutoSize = True
        Me.rb_female.Location = New System.Drawing.Point(13, 51)
        Me.rb_female.Name = "rb_female"
        Me.rb_female.Size = New System.Drawing.Size(79, 22)
        Me.rb_female.TabIndex = 1
        Me.rb_female.TabStop = True
        Me.rb_female.Text = "Female"
        Me.rb_female.UseVisualStyleBackColor = True
        '
        'rb_male
        '
        Me.rb_male.AutoSize = True
        Me.rb_male.Location = New System.Drawing.Point(12, 23)
        Me.rb_male.Name = "rb_male"
        Me.rb_male.Size = New System.Drawing.Size(60, 22)
        Me.rb_male.TabIndex = 0
        Me.rb_male.TabStop = True
        Me.rb_male.Text = "Male"
        Me.rb_male.UseVisualStyleBackColor = True
        '
        'gb_patientID
        '
        Me.gb_patientID.Controls.Add(Me.txt_patientID)
        Me.gb_patientID.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_patientID.ForeColor = System.Drawing.Color.White
        Me.gb_patientID.Location = New System.Drawing.Point(611, 175)
        Me.gb_patientID.Name = "gb_patientID"
        Me.gb_patientID.Size = New System.Drawing.Size(137, 64)
        Me.gb_patientID.TabIndex = 5
        Me.gb_patientID.TabStop = False
        Me.gb_patientID.Text = "PATIENT ID"
        '
        'txt_patientID
        '
        Me.txt_patientID.Location = New System.Drawing.Point(6, 25)
        Me.txt_patientID.Name = "txt_patientID"
        Me.txt_patientID.Size = New System.Drawing.Size(125, 26)
        Me.txt_patientID.TabIndex = 1
        '
        'gb_hospNO
        '
        Me.gb_hospNO.Controls.Add(Me.txt_hospitalNO)
        Me.gb_hospNO.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_hospNO.ForeColor = System.Drawing.Color.White
        Me.gb_hospNO.Location = New System.Drawing.Point(233, 263)
        Me.gb_hospNO.Name = "gb_hospNO"
        Me.gb_hospNO.Size = New System.Drawing.Size(137, 64)
        Me.gb_hospNO.TabIndex = 6
        Me.gb_hospNO.TabStop = False
        Me.gb_hospNO.Text = "HOSPITAL NO."
        '
        'txt_hospitalNO
        '
        Me.txt_hospitalNO.Location = New System.Drawing.Point(6, 25)
        Me.txt_hospitalNO.Name = "txt_hospitalNO"
        Me.txt_hospitalNO.Size = New System.Drawing.Size(125, 26)
        Me.txt_hospitalNO.TabIndex = 1
        '
        'gb_civil
        '
        Me.gb_civil.Controls.Add(Me.rb_others)
        Me.gb_civil.Controls.Add(Me.rb_widow)
        Me.gb_civil.Controls.Add(Me.rb_married)
        Me.gb_civil.Controls.Add(Me.rb_single)
        Me.gb_civil.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_civil.ForeColor = System.Drawing.Color.White
        Me.gb_civil.Location = New System.Drawing.Point(376, 263)
        Me.gb_civil.Name = "gb_civil"
        Me.gb_civil.Size = New System.Drawing.Size(223, 82)
        Me.gb_civil.TabIndex = 8
        Me.gb_civil.TabStop = False
        Me.gb_civil.Text = "CIVIL STATUS"
        '
        'rb_others
        '
        Me.rb_others.AutoSize = True
        Me.rb_others.Location = New System.Drawing.Point(122, 50)
        Me.rb_others.Name = "rb_others"
        Me.rb_others.Size = New System.Drawing.Size(72, 22)
        Me.rb_others.TabIndex = 5
        Me.rb_others.TabStop = True
        Me.rb_others.Text = "Others"
        Me.rb_others.UseVisualStyleBackColor = True
        '
        'rb_widow
        '
        Me.rb_widow.AutoSize = True
        Me.rb_widow.Location = New System.Drawing.Point(122, 25)
        Me.rb_widow.Name = "rb_widow"
        Me.rb_widow.Size = New System.Drawing.Size(74, 22)
        Me.rb_widow.TabIndex = 4
        Me.rb_widow.TabStop = True
        Me.rb_widow.Text = "Widow"
        Me.rb_widow.UseVisualStyleBackColor = True
        '
        'rb_married
        '
        Me.rb_married.AutoSize = True
        Me.rb_married.Location = New System.Drawing.Point(23, 50)
        Me.rb_married.Name = "rb_married"
        Me.rb_married.Size = New System.Drawing.Size(80, 22)
        Me.rb_married.TabIndex = 3
        Me.rb_married.TabStop = True
        Me.rb_married.Text = "Married"
        Me.rb_married.UseVisualStyleBackColor = True
        '
        'rb_single
        '
        Me.rb_single.AutoSize = True
        Me.rb_single.Location = New System.Drawing.Point(23, 25)
        Me.rb_single.Name = "rb_single"
        Me.rb_single.Size = New System.Drawing.Size(70, 22)
        Me.rb_single.TabIndex = 2
        Me.rb_single.TabStop = True
        Me.rb_single.Text = "Single"
        Me.rb_single.UseVisualStyleBackColor = True
        '
        'gb_nationality
        '
        Me.gb_nationality.Controls.Add(Me.txt_nationality)
        Me.gb_nationality.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_nationality.ForeColor = System.Drawing.Color.White
        Me.gb_nationality.Location = New System.Drawing.Point(605, 263)
        Me.gb_nationality.Name = "gb_nationality"
        Me.gb_nationality.Size = New System.Drawing.Size(143, 64)
        Me.gb_nationality.TabIndex = 9
        Me.gb_nationality.TabStop = False
        Me.gb_nationality.Text = "NATIONALITY"
        '
        'txt_nationality
        '
        Me.txt_nationality.Location = New System.Drawing.Point(6, 25)
        Me.txt_nationality.Name = "txt_nationality"
        Me.txt_nationality.Size = New System.Drawing.Size(131, 26)
        Me.txt_nationality.TabIndex = 1
        '
        'gb_religion
        '
        Me.gb_religion.Controls.Add(Me.txt_religion)
        Me.gb_religion.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_religion.ForeColor = System.Drawing.Color.White
        Me.gb_religion.Location = New System.Drawing.Point(605, 351)
        Me.gb_religion.Name = "gb_religion"
        Me.gb_religion.Size = New System.Drawing.Size(143, 65)
        Me.gb_religion.TabIndex = 10
        Me.gb_religion.TabStop = False
        Me.gb_religion.Text = "RELIGION"
        '
        'txt_religion
        '
        Me.txt_religion.Location = New System.Drawing.Point(6, 25)
        Me.txt_religion.Name = "txt_religion"
        Me.txt_religion.Size = New System.Drawing.Size(131, 26)
        Me.txt_religion.TabIndex = 1
        '
        'gb_address
        '
        Me.gb_address.Controls.Add(Me.txt_civil)
        Me.gb_address.Controls.Add(Me.txt_address)
        Me.gb_address.Controls.Add(Me.lbl_address)
        Me.gb_address.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_address.ForeColor = System.Drawing.Color.White
        Me.gb_address.Location = New System.Drawing.Point(233, 352)
        Me.gb_address.Name = "gb_address"
        Me.gb_address.Size = New System.Drawing.Size(366, 81)
        Me.gb_address.TabIndex = 11
        Me.gb_address.TabStop = False
        Me.gb_address.Text = "HOME ADDRESS"
        '
        'txt_civil
        '
        Me.txt_civil.Location = New System.Drawing.Point(263, -11)
        Me.txt_civil.Name = "txt_civil"
        Me.txt_civil.Size = New System.Drawing.Size(100, 26)
        Me.txt_civil.TabIndex = 41
        Me.txt_civil.Text = "Not Defined"
        Me.txt_civil.Visible = False
        '
        'txt_address
        '
        Me.txt_address.Location = New System.Drawing.Point(6, 24)
        Me.txt_address.Name = "txt_address"
        Me.txt_address.Size = New System.Drawing.Size(354, 26)
        Me.txt_address.TabIndex = 3
        '
        'lbl_address
        '
        Me.lbl_address.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_address.Location = New System.Drawing.Point(3, 42)
        Me.lbl_address.Name = "lbl_address"
        Me.lbl_address.Size = New System.Drawing.Size(360, 37)
        Me.lbl_address.TabIndex = 2
        Me.lbl_address.Text = "House no. or Blk/Street or Sitio/Brgy./Municipality/Province or City"
        Me.lbl_address.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'gb_email
        '
        Me.gb_email.Controls.Add(Me.txt_email)
        Me.gb_email.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_email.ForeColor = System.Drawing.Color.White
        Me.gb_email.Location = New System.Drawing.Point(233, 439)
        Me.gb_email.Name = "gb_email"
        Me.gb_email.Size = New System.Drawing.Size(262, 63)
        Me.gb_email.TabIndex = 12
        Me.gb_email.TabStop = False
        Me.gb_email.Text = "E-MAIL ADDRESS"
        '
        'txt_email
        '
        Me.txt_email.Location = New System.Drawing.Point(6, 24)
        Me.txt_email.Name = "txt_email"
        Me.txt_email.Size = New System.Drawing.Size(250, 26)
        Me.txt_email.TabIndex = 3
        '
        'gb_contactNO
        '
        Me.gb_contactNO.Controls.Add(Me.txt_contactNO)
        Me.gb_contactNO.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_contactNO.ForeColor = System.Drawing.Color.White
        Me.gb_contactNO.Location = New System.Drawing.Point(502, 439)
        Me.gb_contactNO.Name = "gb_contactNO"
        Me.gb_contactNO.Size = New System.Drawing.Size(246, 63)
        Me.gb_contactNO.TabIndex = 13
        Me.gb_contactNO.TabStop = False
        Me.gb_contactNO.Text = "CONTACT NO/s"
        '
        'txt_contactNO
        '
        Me.txt_contactNO.Location = New System.Drawing.Point(6, 24)
        Me.txt_contactNO.Name = "txt_contactNO"
        Me.txt_contactNO.Size = New System.Drawing.Size(234, 26)
        Me.txt_contactNO.TabIndex = 3
        '
        'gb_referred
        '
        Me.gb_referred.Controls.Add(Me.txt_referred)
        Me.gb_referred.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_referred.ForeColor = System.Drawing.Color.White
        Me.gb_referred.Location = New System.Drawing.Point(233, 508)
        Me.gb_referred.Name = "gb_referred"
        Me.gb_referred.Size = New System.Drawing.Size(256, 63)
        Me.gb_referred.TabIndex = 14
        Me.gb_referred.TabStop = False
        Me.gb_referred.Text = "REFERRED BY"
        '
        'txt_referred
        '
        Me.txt_referred.Location = New System.Drawing.Point(6, 24)
        Me.txt_referred.Name = "txt_referred"
        Me.txt_referred.Size = New System.Drawing.Size(244, 26)
        Me.txt_referred.TabIndex = 3
        '
        'gb_specialization
        '
        Me.gb_specialization.Controls.Add(Me.txt_specialization)
        Me.gb_specialization.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_specialization.ForeColor = System.Drawing.Color.White
        Me.gb_specialization.Location = New System.Drawing.Point(492, 508)
        Me.gb_specialization.Name = "gb_specialization"
        Me.gb_specialization.Size = New System.Drawing.Size(256, 63)
        Me.gb_specialization.TabIndex = 15
        Me.gb_specialization.TabStop = False
        Me.gb_specialization.Text = "SPECIALIZATION/HOSP."
        '
        'txt_specialization
        '
        Me.txt_specialization.Location = New System.Drawing.Point(6, 24)
        Me.txt_specialization.Name = "txt_specialization"
        Me.txt_specialization.Size = New System.Drawing.Size(244, 26)
        Me.txt_specialization.TabIndex = 3
        '
        'gb_physician
        '
        Me.gb_physician.Controls.Add(Me.txt_physician)
        Me.gb_physician.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_physician.ForeColor = System.Drawing.Color.White
        Me.gb_physician.Location = New System.Drawing.Point(233, 577)
        Me.gb_physician.Name = "gb_physician"
        Me.gb_physician.Size = New System.Drawing.Size(173, 63)
        Me.gb_physician.TabIndex = 16
        Me.gb_physician.TabStop = False
        Me.gb_physician.Text = "PHYSICIAN"
        '
        'txt_physician
        '
        Me.txt_physician.Location = New System.Drawing.Point(6, 24)
        Me.txt_physician.Name = "txt_physician"
        Me.txt_physician.Size = New System.Drawing.Size(161, 26)
        Me.txt_physician.TabIndex = 3
        '
        'gb_surgeon
        '
        Me.gb_surgeon.Controls.Add(Me.txt_surgeon)
        Me.gb_surgeon.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_surgeon.ForeColor = System.Drawing.Color.White
        Me.gb_surgeon.Location = New System.Drawing.Point(412, 577)
        Me.gb_surgeon.Name = "gb_surgeon"
        Me.gb_surgeon.Size = New System.Drawing.Size(173, 63)
        Me.gb_surgeon.TabIndex = 17
        Me.gb_surgeon.TabStop = False
        Me.gb_surgeon.Text = "SURGEON"
        '
        'txt_surgeon
        '
        Me.txt_surgeon.Location = New System.Drawing.Point(6, 24)
        Me.txt_surgeon.Name = "txt_surgeon"
        Me.txt_surgeon.Size = New System.Drawing.Size(161, 26)
        Me.txt_surgeon.TabIndex = 3
        '
        'gb_patientclass
        '
        Me.gb_patientclass.Controls.Add(Me.rb_pay)
        Me.gb_patientclass.Controls.Add(Me.rb_service)
        Me.gb_patientclass.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_patientclass.ForeColor = System.Drawing.Color.White
        Me.gb_patientclass.Location = New System.Drawing.Point(591, 577)
        Me.gb_patientclass.Name = "gb_patientclass"
        Me.gb_patientclass.Size = New System.Drawing.Size(157, 63)
        Me.gb_patientclass.TabIndex = 18
        Me.gb_patientclass.TabStop = False
        Me.gb_patientclass.Text = "PATIENT CLASS."
        '
        'rb_pay
        '
        Me.rb_pay.AutoSize = True
        Me.rb_pay.Location = New System.Drawing.Point(93, 28)
        Me.rb_pay.Name = "rb_pay"
        Me.rb_pay.Size = New System.Drawing.Size(53, 22)
        Me.rb_pay.TabIndex = 7
        Me.rb_pay.TabStop = True
        Me.rb_pay.Text = "Pay"
        Me.rb_pay.UseVisualStyleBackColor = True
        '
        'rb_service
        '
        Me.rb_service.AutoSize = True
        Me.rb_service.Location = New System.Drawing.Point(11, 28)
        Me.rb_service.Name = "rb_service"
        Me.rb_service.Size = New System.Drawing.Size(79, 22)
        Me.rb_service.TabIndex = 6
        Me.rb_service.TabStop = True
        Me.rb_service.Text = "Service"
        Me.rb_service.UseVisualStyleBackColor = True
        '
        'lbl_emergency
        '
        Me.lbl_emergency.BackColor = System.Drawing.Color.DodgerBlue
        Me.lbl_emergency.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_emergency.ForeColor = System.Drawing.Color.White
        Me.lbl_emergency.Location = New System.Drawing.Point(230, 643)
        Me.lbl_emergency.Name = "lbl_emergency"
        Me.lbl_emergency.Size = New System.Drawing.Size(518, 23)
        Me.lbl_emergency.TabIndex = 19
        Me.lbl_emergency.Text = "EMERGENCY CONTACT DATA"
        Me.lbl_emergency.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'gb_emerrelationship
        '
        Me.gb_emerrelationship.Controls.Add(Me.txt_emerrelationship)
        Me.gb_emerrelationship.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_emerrelationship.ForeColor = System.Drawing.Color.White
        Me.gb_emerrelationship.Location = New System.Drawing.Point(475, 669)
        Me.gb_emerrelationship.Name = "gb_emerrelationship"
        Me.gb_emerrelationship.Size = New System.Drawing.Size(273, 63)
        Me.gb_emerrelationship.TabIndex = 21
        Me.gb_emerrelationship.TabStop = False
        Me.gb_emerrelationship.Text = "RELATIONSHIP TO THE PATIENT"
        '
        'txt_emerrelationship
        '
        Me.txt_emerrelationship.Location = New System.Drawing.Point(6, 24)
        Me.txt_emerrelationship.Name = "txt_emerrelationship"
        Me.txt_emerrelationship.Size = New System.Drawing.Size(261, 26)
        Me.txt_emerrelationship.TabIndex = 3
        '
        'gb_emername
        '
        Me.gb_emername.Controls.Add(Me.txt_emername)
        Me.gb_emername.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_emername.ForeColor = System.Drawing.Color.White
        Me.gb_emername.Location = New System.Drawing.Point(233, 669)
        Me.gb_emername.Name = "gb_emername"
        Me.gb_emername.Size = New System.Drawing.Size(236, 63)
        Me.gb_emername.TabIndex = 20
        Me.gb_emername.TabStop = False
        Me.gb_emername.Text = "NAME"
        '
        'txt_emername
        '
        Me.txt_emername.Location = New System.Drawing.Point(6, 24)
        Me.txt_emername.Name = "txt_emername"
        Me.txt_emername.Size = New System.Drawing.Size(224, 26)
        Me.txt_emername.TabIndex = 3
        '
        'gb_emercontact
        '
        Me.gb_emercontact.Controls.Add(Me.txt_emercontact)
        Me.gb_emercontact.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_emercontact.ForeColor = System.Drawing.Color.White
        Me.gb_emercontact.Location = New System.Drawing.Point(492, 738)
        Me.gb_emercontact.Name = "gb_emercontact"
        Me.gb_emercontact.Size = New System.Drawing.Size(256, 63)
        Me.gb_emercontact.TabIndex = 23
        Me.gb_emercontact.TabStop = False
        Me.gb_emercontact.Text = "CONTACT NO/s"
        '
        'txt_emercontact
        '
        Me.txt_emercontact.Location = New System.Drawing.Point(6, 24)
        Me.txt_emercontact.Name = "txt_emercontact"
        Me.txt_emercontact.Size = New System.Drawing.Size(244, 26)
        Me.txt_emercontact.TabIndex = 3
        '
        'gb_emeraddress
        '
        Me.gb_emeraddress.Controls.Add(Me.txt_emeraddress)
        Me.gb_emeraddress.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_emeraddress.ForeColor = System.Drawing.Color.White
        Me.gb_emeraddress.Location = New System.Drawing.Point(233, 738)
        Me.gb_emeraddress.Name = "gb_emeraddress"
        Me.gb_emeraddress.Size = New System.Drawing.Size(256, 63)
        Me.gb_emeraddress.TabIndex = 22
        Me.gb_emeraddress.TabStop = False
        Me.gb_emeraddress.Text = "ADDRESS"
        '
        'txt_emeraddress
        '
        Me.txt_emeraddress.Location = New System.Drawing.Point(6, 24)
        Me.txt_emeraddress.Name = "txt_emeraddress"
        Me.txt_emeraddress.Size = New System.Drawing.Size(244, 26)
        Me.txt_emeraddress.TabIndex = 3
        '
        'lbl_employment
        '
        Me.lbl_employment.BackColor = System.Drawing.Color.DodgerBlue
        Me.lbl_employment.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_employment.ForeColor = System.Drawing.Color.White
        Me.lbl_employment.Location = New System.Drawing.Point(230, 804)
        Me.lbl_employment.Name = "lbl_employment"
        Me.lbl_employment.Size = New System.Drawing.Size(518, 23)
        Me.lbl_employment.TabIndex = 24
        Me.lbl_employment.Text = "EMPLOYMENT"
        Me.lbl_employment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'gb_occupation
        '
        Me.gb_occupation.Controls.Add(Me.txt_occupation)
        Me.gb_occupation.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_occupation.ForeColor = System.Drawing.Color.White
        Me.gb_occupation.Location = New System.Drawing.Point(233, 830)
        Me.gb_occupation.Name = "gb_occupation"
        Me.gb_occupation.Size = New System.Drawing.Size(256, 63)
        Me.gb_occupation.TabIndex = 25
        Me.gb_occupation.TabStop = False
        Me.gb_occupation.Text = "OCCUPATION"
        '
        'txt_occupation
        '
        Me.txt_occupation.Location = New System.Drawing.Point(6, 24)
        Me.txt_occupation.Name = "txt_occupation"
        Me.txt_occupation.Size = New System.Drawing.Size(244, 26)
        Me.txt_occupation.TabIndex = 3
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txt_officecontact)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(233, 908)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(256, 63)
        Me.GroupBox2.TabIndex = 26
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "OFFICE CONTACT NO/s"
        '
        'txt_officecontact
        '
        Me.txt_officecontact.Location = New System.Drawing.Point(6, 24)
        Me.txt_officecontact.Name = "txt_officecontact"
        Me.txt_officecontact.Size = New System.Drawing.Size(244, 26)
        Me.txt_officecontact.TabIndex = 3
        '
        'gb_company
        '
        Me.gb_company.Controls.Add(Me.txt_dept)
        Me.gb_company.Controls.Add(Me.rb_otherdept)
        Me.gb_company.Controls.Add(Me.rb_nktiemployee)
        Me.gb_company.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_company.ForeColor = System.Drawing.Color.White
        Me.gb_company.Location = New System.Drawing.Point(492, 830)
        Me.gb_company.Name = "gb_company"
        Me.gb_company.Size = New System.Drawing.Size(256, 141)
        Me.gb_company.TabIndex = 27
        Me.gb_company.TabStop = False
        Me.gb_company.Text = "COMPANY"
        '
        'txt_dept
        '
        Me.txt_dept.Enabled = False
        Me.txt_dept.Location = New System.Drawing.Point(6, 106)
        Me.txt_dept.Name = "txt_dept"
        Me.txt_dept.Size = New System.Drawing.Size(244, 26)
        Me.txt_dept.TabIndex = 10
        '
        'rb_otherdept
        '
        Me.rb_otherdept.AutoSize = True
        Me.rb_otherdept.Location = New System.Drawing.Point(14, 61)
        Me.rb_otherdept.Name = "rb_otherdept"
        Me.rb_otherdept.Size = New System.Drawing.Size(132, 22)
        Me.rb_otherdept.TabIndex = 9
        Me.rb_otherdept.TabStop = True
        Me.rb_otherdept.Text = "Others, Specify"
        Me.rb_otherdept.UseVisualStyleBackColor = True
        '
        'rb_nktiemployee
        '
        Me.rb_nktiemployee.AutoSize = True
        Me.rb_nktiemployee.Location = New System.Drawing.Point(14, 24)
        Me.rb_nktiemployee.Name = "rb_nktiemployee"
        Me.rb_nktiemployee.Size = New System.Drawing.Size(224, 22)
        Me.rb_nktiemployee.TabIndex = 7
        Me.rb_nktiemployee.TabStop = True
        Me.rb_nktiemployee.Text = "NKTI Employee, Department"
        Me.rb_nktiemployee.UseVisualStyleBackColor = True
        '
        'gb_officeaddress
        '
        Me.gb_officeaddress.Controls.Add(Me.txt_officeaddress)
        Me.gb_officeaddress.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_officeaddress.ForeColor = System.Drawing.Color.White
        Me.gb_officeaddress.Location = New System.Drawing.Point(233, 977)
        Me.gb_officeaddress.Name = "gb_officeaddress"
        Me.gb_officeaddress.Size = New System.Drawing.Size(515, 63)
        Me.gb_officeaddress.TabIndex = 28
        Me.gb_officeaddress.TabStop = False
        Me.gb_officeaddress.Text = "OFFICE ADDRESS"
        '
        'txt_officeaddress
        '
        Me.txt_officeaddress.Location = New System.Drawing.Point(6, 24)
        Me.txt_officeaddress.Name = "txt_officeaddress"
        Me.txt_officeaddress.Size = New System.Drawing.Size(503, 26)
        Me.txt_officeaddress.TabIndex = 3
        '
        'lbl_medical
        '
        Me.lbl_medical.BackColor = System.Drawing.Color.DodgerBlue
        Me.lbl_medical.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_medical.ForeColor = System.Drawing.Color.White
        Me.lbl_medical.Location = New System.Drawing.Point(230, 1043)
        Me.lbl_medical.Name = "lbl_medical"
        Me.lbl_medical.Size = New System.Drawing.Size(518, 23)
        Me.lbl_medical.TabIndex = 29
        Me.lbl_medical.Text = "MEDICAL DATA"
        Me.lbl_medical.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'gb_familymed
        '
        Me.gb_familymed.Controls.Add(Me.cmb_familymed)
        Me.gb_familymed.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_familymed.ForeColor = System.Drawing.Color.White
        Me.gb_familymed.Location = New System.Drawing.Point(492, 1069)
        Me.gb_familymed.Name = "gb_familymed"
        Me.gb_familymed.Size = New System.Drawing.Size(256, 63)
        Me.gb_familymed.TabIndex = 31
        Me.gb_familymed.TabStop = False
        Me.gb_familymed.Text = "FAMILY MED. HISTORY"
        '
        'cmb_familymed
        '
        Me.cmb_familymed.FormattingEnabled = True
        Me.cmb_familymed.Location = New System.Drawing.Point(6, 25)
        Me.cmb_familymed.Name = "cmb_familymed"
        Me.cmb_familymed.Size = New System.Drawing.Size(244, 26)
        Me.cmb_familymed.TabIndex = 1
        '
        'gb_personalmed
        '
        Me.gb_personalmed.Controls.Add(Me.cmb_personalmed)
        Me.gb_personalmed.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_personalmed.ForeColor = System.Drawing.Color.White
        Me.gb_personalmed.Location = New System.Drawing.Point(233, 1069)
        Me.gb_personalmed.Name = "gb_personalmed"
        Me.gb_personalmed.Size = New System.Drawing.Size(256, 63)
        Me.gb_personalmed.TabIndex = 30
        Me.gb_personalmed.TabStop = False
        Me.gb_personalmed.Text = "PERSONAL MED. HISTORY"
        '
        'cmb_personalmed
        '
        Me.cmb_personalmed.FormattingEnabled = True
        Me.cmb_personalmed.Location = New System.Drawing.Point(6, 25)
        Me.cmb_personalmed.Name = "cmb_personalmed"
        Me.cmb_personalmed.Size = New System.Drawing.Size(244, 26)
        Me.cmb_personalmed.TabIndex = 0
        '
        'lbl_surgical
        '
        Me.lbl_surgical.BackColor = System.Drawing.Color.DodgerBlue
        Me.lbl_surgical.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_surgical.ForeColor = System.Drawing.Color.White
        Me.lbl_surgical.Location = New System.Drawing.Point(230, 1135)
        Me.lbl_surgical.Name = "lbl_surgical"
        Me.lbl_surgical.Size = New System.Drawing.Size(518, 23)
        Me.lbl_surgical.TabIndex = 32
        Me.lbl_surgical.Text = "SURGICAL HISTORY"
        Me.lbl_surgical.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'gb_surgical
        '
        Me.gb_surgical.Controls.Add(Me.txt_dateperformed)
        Me.gb_surgical.Controls.Add(Me.txt_surgical)
        Me.gb_surgical.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_surgical.ForeColor = System.Drawing.Color.White
        Me.gb_surgical.Location = New System.Drawing.Point(233, 1161)
        Me.gb_surgical.Name = "gb_surgical"
        Me.gb_surgical.Size = New System.Drawing.Size(515, 63)
        Me.gb_surgical.TabIndex = 33
        Me.gb_surgical.TabStop = False
        Me.gb_surgical.Text = "NAME OF OPERATION/DATE PERFORMED"
        '
        'txt_dateperformed
        '
        Me.txt_dateperformed.Location = New System.Drawing.Point(321, 24)
        Me.txt_dateperformed.Name = "txt_dateperformed"
        Me.txt_dateperformed.Size = New System.Drawing.Size(183, 26)
        Me.txt_dateperformed.TabIndex = 4
        '
        'txt_surgical
        '
        Me.txt_surgical.Location = New System.Drawing.Point(6, 24)
        Me.txt_surgical.Name = "txt_surgical"
        Me.txt_surgical.Size = New System.Drawing.Size(310, 26)
        Me.txt_surgical.TabIndex = 3
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.DarkCyan
        Me.Panel1.Controls.Add(Me.lbl_close)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(-2, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(804, 27)
        Me.Panel1.TabIndex = 34
        '
        'lbl_close
        '
        Me.lbl_close.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_close.ForeColor = System.Drawing.Color.Red
        Me.lbl_close.Location = New System.Drawing.Point(761, -1)
        Me.lbl_close.Name = "lbl_close"
        Me.lbl_close.Size = New System.Drawing.Size(27, 29)
        Me.lbl_close.TabIndex = 7
        Me.lbl_close.Text = "×"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(162, 18)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Recipient Registration"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Location = New System.Drawing.Point(60, 95)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(117, 131)
        Me.GroupBox1.TabIndex = 35
        Me.GroupBox1.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(6, 16)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(104, 104)
        Me.PictureBox1.TabIndex = 36
        Me.PictureBox1.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.BunifuFlatButton5)
        Me.Panel3.Controls.Add(Me.BunifuFlatButton1)
        Me.Panel3.Location = New System.Drawing.Point(26, 241)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(184, 116)
        Me.Panel3.TabIndex = 36
        '
        'BunifuFlatButton5
        '
        Me.BunifuFlatButton5.Activecolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton5.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton5.BorderRadius = 0
        Me.BunifuFlatButton5.ButtonText = "Home"
        Me.BunifuFlatButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton5.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton5.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton5.Iconimage = Global.Prologue.My.Resources.Resources.home
        Me.BunifuFlatButton5.Iconimage_right = Nothing
        Me.BunifuFlatButton5.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton5.Iconimage_Selected = Nothing
        Me.BunifuFlatButton5.IconRightVisible = True
        Me.BunifuFlatButton5.IconRightZoom = 0.0R
        Me.BunifuFlatButton5.IconVisible = True
        Me.BunifuFlatButton5.IconZoom = 80.0R
        Me.BunifuFlatButton5.IsTab = False
        Me.BunifuFlatButton5.Location = New System.Drawing.Point(3, 4)
        Me.BunifuFlatButton5.Name = "BunifuFlatButton5"
        Me.BunifuFlatButton5.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton5.OnHovercolor = System.Drawing.Color.SkyBlue
        Me.BunifuFlatButton5.OnHoverTextColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton5.selected = False
        Me.BunifuFlatButton5.Size = New System.Drawing.Size(174, 48)
        Me.BunifuFlatButton5.TabIndex = 4
        Me.BunifuFlatButton5.Text = "Home"
        Me.BunifuFlatButton5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton5.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton5.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton1
        '
        Me.BunifuFlatButton1.Activecolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton1.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton1.BorderRadius = 0
        Me.BunifuFlatButton1.ButtonText = "Registration"
        Me.BunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton1.Iconimage = Global.Prologue.My.Resources.Resources.Assessment
        Me.BunifuFlatButton1.Iconimage_right = Nothing
        Me.BunifuFlatButton1.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton1.Iconimage_Selected = Nothing
        Me.BunifuFlatButton1.IconRightVisible = True
        Me.BunifuFlatButton1.IconRightZoom = 0.0R
        Me.BunifuFlatButton1.IconVisible = True
        Me.BunifuFlatButton1.IconZoom = 70.0R
        Me.BunifuFlatButton1.IsTab = False
        Me.BunifuFlatButton1.Location = New System.Drawing.Point(3, 58)
        Me.BunifuFlatButton1.Name = "BunifuFlatButton1"
        Me.BunifuFlatButton1.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton1.OnHovercolor = System.Drawing.Color.SkyBlue
        Me.BunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton1.selected = False
        Me.BunifuFlatButton1.Size = New System.Drawing.Size(175, 48)
        Me.BunifuFlatButton1.TabIndex = 0
        Me.BunifuFlatButton1.Text = "Registration"
        Me.BunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton1.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'lbl_verify
        '
        Me.lbl_verify.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_verify.ForeColor = System.Drawing.Color.White
        Me.lbl_verify.Location = New System.Drawing.Point(236, 1243)
        Me.lbl_verify.Name = "lbl_verify"
        Me.lbl_verify.Size = New System.Drawing.Size(360, 37)
        Me.lbl_verify.TabIndex = 37
        Me.lbl_verify.Text = "I certify that all of the information above are true and correct."
        Me.lbl_verify.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chk_verify
        '
        Me.chk_verify.AutoSize = True
        Me.chk_verify.Location = New System.Drawing.Point(231, 1255)
        Me.chk_verify.Name = "chk_verify"
        Me.chk_verify.Size = New System.Drawing.Size(15, 14)
        Me.chk_verify.TabIndex = 38
        Me.chk_verify.UseVisualStyleBackColor = True
        '
        'btn_submit
        '
        Me.btn_submit.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.btn_submit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_submit.FlatAppearance.BorderSize = 0
        Me.btn_submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_submit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_submit.ForeColor = System.Drawing.Color.White
        Me.btn_submit.Location = New System.Drawing.Point(637, 1239)
        Me.btn_submit.Name = "btn_submit"
        Me.btn_submit.Size = New System.Drawing.Size(95, 45)
        Me.btn_submit.TabIndex = 39
        Me.btn_submit.Text = "SUBMIT"
        Me.btn_submit.UseVisualStyleBackColor = False
        '
        'txt_gender
        '
        Me.txt_gender.Location = New System.Drawing.Point(505, 254)
        Me.txt_gender.Name = "txt_gender"
        Me.txt_gender.Size = New System.Drawing.Size(100, 20)
        Me.txt_gender.TabIndex = 40
        Me.txt_gender.Text = "Not Defined"
        Me.txt_gender.Visible = False
        '
        'txt_class
        '
        Me.txt_class.Location = New System.Drawing.Point(616, 633)
        Me.txt_class.Name = "txt_class"
        Me.txt_class.Size = New System.Drawing.Size(100, 20)
        Me.txt_class.TabIndex = 42
        Me.txt_class.Text = "Not Defined"
        Me.txt_class.Visible = False
        '
        'txt_company
        '
        Me.txt_company.Location = New System.Drawing.Point(496, 968)
        Me.txt_company.Name = "txt_company"
        Me.txt_company.Size = New System.Drawing.Size(100, 20)
        Me.txt_company.TabIndex = 43
        Me.txt_company.Text = "Not Defined"
        Me.txt_company.Visible = False
        '
        'frm_recipient
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(801, 562)
        Me.Controls.Add(Me.txt_company)
        Me.Controls.Add(Me.txt_class)
        Me.Controls.Add(Me.txt_gender)
        Me.Controls.Add(Me.btn_submit)
        Me.Controls.Add(Me.chk_verify)
        Me.Controls.Add(Me.lbl_verify)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.gb_surgical)
        Me.Controls.Add(Me.lbl_surgical)
        Me.Controls.Add(Me.gb_familymed)
        Me.Controls.Add(Me.gb_personalmed)
        Me.Controls.Add(Me.lbl_medical)
        Me.Controls.Add(Me.gb_officeaddress)
        Me.Controls.Add(Me.gb_company)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.gb_occupation)
        Me.Controls.Add(Me.lbl_employment)
        Me.Controls.Add(Me.gb_emercontact)
        Me.Controls.Add(Me.gb_emeraddress)
        Me.Controls.Add(Me.gb_emerrelationship)
        Me.Controls.Add(Me.gb_emername)
        Me.Controls.Add(Me.lbl_emergency)
        Me.Controls.Add(Me.gb_patientclass)
        Me.Controls.Add(Me.gb_surgeon)
        Me.Controls.Add(Me.gb_physician)
        Me.Controls.Add(Me.gb_specialization)
        Me.Controls.Add(Me.gb_referred)
        Me.Controls.Add(Me.gb_contactNO)
        Me.Controls.Add(Me.gb_email)
        Me.Controls.Add(Me.gb_address)
        Me.Controls.Add(Me.gb_religion)
        Me.Controls.Add(Me.gb_nationality)
        Me.Controls.Add(Me.gb_civil)
        Me.Controls.Add(Me.gb_hospNO)
        Me.Controls.Add(Me.gb_patientID)
        Me.Controls.Add(Me.gb_gender)
        Me.Controls.Add(Me.gb_age)
        Me.Controls.Add(Me.gb_birthdate)
        Me.Controls.Add(Me.gb_patientname)
        Me.Controls.Add(Me.lbl_patientprofile)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_recipient"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frm_recipient"
        Me.gb_patientname.ResumeLayout(False)
        Me.gb_patientname.PerformLayout()
        Me.gb_birthdate.ResumeLayout(False)
        Me.gb_birthdate.PerformLayout()
        Me.gb_age.ResumeLayout(False)
        Me.gb_age.PerformLayout()
        Me.gb_gender.ResumeLayout(False)
        Me.gb_gender.PerformLayout()
        Me.gb_patientID.ResumeLayout(False)
        Me.gb_patientID.PerformLayout()
        Me.gb_hospNO.ResumeLayout(False)
        Me.gb_hospNO.PerformLayout()
        Me.gb_civil.ResumeLayout(False)
        Me.gb_civil.PerformLayout()
        Me.gb_nationality.ResumeLayout(False)
        Me.gb_nationality.PerformLayout()
        Me.gb_religion.ResumeLayout(False)
        Me.gb_religion.PerformLayout()
        Me.gb_address.ResumeLayout(False)
        Me.gb_address.PerformLayout()
        Me.gb_email.ResumeLayout(False)
        Me.gb_email.PerformLayout()
        Me.gb_contactNO.ResumeLayout(False)
        Me.gb_contactNO.PerformLayout()
        Me.gb_referred.ResumeLayout(False)
        Me.gb_referred.PerformLayout()
        Me.gb_specialization.ResumeLayout(False)
        Me.gb_specialization.PerformLayout()
        Me.gb_physician.ResumeLayout(False)
        Me.gb_physician.PerformLayout()
        Me.gb_surgeon.ResumeLayout(False)
        Me.gb_surgeon.PerformLayout()
        Me.gb_patientclass.ResumeLayout(False)
        Me.gb_patientclass.PerformLayout()
        Me.gb_emerrelationship.ResumeLayout(False)
        Me.gb_emerrelationship.PerformLayout()
        Me.gb_emername.ResumeLayout(False)
        Me.gb_emername.PerformLayout()
        Me.gb_emercontact.ResumeLayout(False)
        Me.gb_emercontact.PerformLayout()
        Me.gb_emeraddress.ResumeLayout(False)
        Me.gb_emeraddress.PerformLayout()
        Me.gb_occupation.ResumeLayout(False)
        Me.gb_occupation.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.gb_company.ResumeLayout(False)
        Me.gb_company.PerformLayout()
        Me.gb_officeaddress.ResumeLayout(False)
        Me.gb_officeaddress.PerformLayout()
        Me.gb_familymed.ResumeLayout(False)
        Me.gb_personalmed.ResumeLayout(False)
        Me.gb_surgical.ResumeLayout(False)
        Me.gb_surgical.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl_patientprofile As System.Windows.Forms.Label
    Friend WithEvents gb_patientname As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_middlename As System.Windows.Forms.Label
    Friend WithEvents lbl_firstname As System.Windows.Forms.Label
    Friend WithEvents lbl_lastname As System.Windows.Forms.Label
    Friend WithEvents txt_middlename As System.Windows.Forms.TextBox
    Friend WithEvents txt_firstname As System.Windows.Forms.TextBox
    Friend WithEvents txt_surname As System.Windows.Forms.TextBox
    Friend WithEvents gb_birthdate As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_year As System.Windows.Forms.Label
    Friend WithEvents lbl_date As System.Windows.Forms.Label
    Friend WithEvents lbl_month As System.Windows.Forms.Label
    Friend WithEvents cmb_year As System.Windows.Forms.ComboBox
    Friend WithEvents cmb_date As System.Windows.Forms.ComboBox
    Friend WithEvents cmb_month As System.Windows.Forms.ComboBox
    Friend WithEvents gb_age As System.Windows.Forms.GroupBox
    Friend WithEvents txt_age As System.Windows.Forms.TextBox
    Friend WithEvents gb_gender As System.Windows.Forms.GroupBox
    Friend WithEvents rb_female As System.Windows.Forms.RadioButton
    Friend WithEvents rb_male As System.Windows.Forms.RadioButton
    Friend WithEvents gb_patientID As System.Windows.Forms.GroupBox
    Friend WithEvents txt_patientID As System.Windows.Forms.TextBox
    Friend WithEvents gb_hospNO As System.Windows.Forms.GroupBox
    Friend WithEvents txt_hospitalNO As System.Windows.Forms.TextBox
    Friend WithEvents gb_civil As System.Windows.Forms.GroupBox
    Friend WithEvents rb_others As System.Windows.Forms.RadioButton
    Friend WithEvents rb_widow As System.Windows.Forms.RadioButton
    Friend WithEvents rb_married As System.Windows.Forms.RadioButton
    Friend WithEvents rb_single As System.Windows.Forms.RadioButton
    Friend WithEvents gb_nationality As System.Windows.Forms.GroupBox
    Friend WithEvents txt_nationality As System.Windows.Forms.TextBox
    Friend WithEvents gb_religion As System.Windows.Forms.GroupBox
    Friend WithEvents txt_religion As System.Windows.Forms.TextBox
    Friend WithEvents gb_address As System.Windows.Forms.GroupBox
    Friend WithEvents txt_address As System.Windows.Forms.TextBox
    Friend WithEvents lbl_address As System.Windows.Forms.Label
    Friend WithEvents gb_email As System.Windows.Forms.GroupBox
    Friend WithEvents txt_email As System.Windows.Forms.TextBox
    Friend WithEvents gb_contactNO As System.Windows.Forms.GroupBox
    Friend WithEvents txt_contactNO As System.Windows.Forms.TextBox
    Friend WithEvents gb_referred As System.Windows.Forms.GroupBox
    Friend WithEvents txt_referred As System.Windows.Forms.TextBox
    Friend WithEvents gb_specialization As System.Windows.Forms.GroupBox
    Friend WithEvents txt_specialization As System.Windows.Forms.TextBox
    Friend WithEvents gb_physician As System.Windows.Forms.GroupBox
    Friend WithEvents txt_physician As System.Windows.Forms.TextBox
    Friend WithEvents gb_surgeon As System.Windows.Forms.GroupBox
    Friend WithEvents txt_surgeon As System.Windows.Forms.TextBox
    Friend WithEvents gb_patientclass As System.Windows.Forms.GroupBox
    Friend WithEvents rb_pay As System.Windows.Forms.RadioButton
    Friend WithEvents rb_service As System.Windows.Forms.RadioButton
    Friend WithEvents lbl_emergency As System.Windows.Forms.Label
    Friend WithEvents gb_emerrelationship As System.Windows.Forms.GroupBox
    Friend WithEvents txt_emerrelationship As System.Windows.Forms.TextBox
    Friend WithEvents gb_emername As System.Windows.Forms.GroupBox
    Friend WithEvents txt_emername As System.Windows.Forms.TextBox
    Friend WithEvents gb_emercontact As System.Windows.Forms.GroupBox
    Friend WithEvents txt_emercontact As System.Windows.Forms.TextBox
    Friend WithEvents gb_emeraddress As System.Windows.Forms.GroupBox
    Friend WithEvents txt_emeraddress As System.Windows.Forms.TextBox
    Friend WithEvents lbl_employment As System.Windows.Forms.Label
    Friend WithEvents gb_occupation As System.Windows.Forms.GroupBox
    Friend WithEvents txt_occupation As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_officecontact As System.Windows.Forms.TextBox
    Friend WithEvents gb_company As System.Windows.Forms.GroupBox
    Friend WithEvents gb_officeaddress As System.Windows.Forms.GroupBox
    Friend WithEvents txt_officeaddress As System.Windows.Forms.TextBox
    Friend WithEvents txt_dept As System.Windows.Forms.TextBox
    Friend WithEvents rb_otherdept As System.Windows.Forms.RadioButton
    Friend WithEvents rb_nktiemployee As System.Windows.Forms.RadioButton
    Friend WithEvents lbl_medical As System.Windows.Forms.Label
    Friend WithEvents gb_familymed As System.Windows.Forms.GroupBox
    Friend WithEvents cmb_familymed As System.Windows.Forms.ComboBox
    Friend WithEvents gb_personalmed As System.Windows.Forms.GroupBox
    Friend WithEvents cmb_personalmed As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_surgical As System.Windows.Forms.Label
    Friend WithEvents gb_surgical As System.Windows.Forms.GroupBox
    Friend WithEvents txt_surgical As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lbl_close As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents BunifuFlatButton5 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents lbl_verify As System.Windows.Forms.Label
    Friend WithEvents chk_verify As System.Windows.Forms.CheckBox
    Friend WithEvents btn_submit As System.Windows.Forms.Button
    Friend WithEvents txt_gender As System.Windows.Forms.TextBox
    Friend WithEvents txt_civil As System.Windows.Forms.TextBox
    Friend WithEvents txt_class As System.Windows.Forms.TextBox
    Friend WithEvents txt_company As System.Windows.Forms.TextBox
    Friend WithEvents txt_dateperformed As System.Windows.Forms.TextBox
End Class
