﻿Imports System.IO
Public Class frm_addeditslideshow
    Private Sub lbl_close_Click(sender As Object, e As EventArgs) Handles lbl_close.Click
        'Close Button at the Upper-right corner
        Me.Close()
    End Sub


    'The MouseMove and MouseLeave events are only for design purpose
    Private Sub lbl_close_MouseMove(sender As Object, e As MouseEventArgs) Handles lbl_close.MouseMove
        lbl_close.BackColor = Color.White
    End Sub

    Private Sub lbl_close_MouseLeave(sender As Object, e As EventArgs) Handles lbl_close.MouseLeave
        lbl_close.BackColor = Color.DarkCyan
    End Sub

    Private Sub btn_browse_Click(sender As Object, e As EventArgs) Handles btn_browse.Click
        OpenFileDialog.Filter = "Picture Files (*)|*.bmp;*.gif;*.jpg"
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            pcbx_preview.Image = Image.FromFile(OpenFileDialog.FileName)
            txt_imagepath.Text = OpenFileDialog.FileName
        End If
    End Sub

    Private Sub frm_addeditslideshow_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        pcbx_preview.SizeMode = PictureBoxSizeMode.StretchImage
    End Sub

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        Dim ms As New MemoryStream
        pcbx_preview.Image.Save(ms, pcbx_preview.Image.RawFormat)
        Dim data As Byte() = ms.GetBuffer
        Connect()
        Dim sql As String
        sql = "INSERT INTO tbl_slideshow VALUES (@entry, @image, @desc)"
        Cmd.Prepare()
        Cmd.Parameters.AddWithValue("@entry", frm_slideshowedit.lstvw_items.Items.Count + 1)
        Cmd.Parameters.AddWithValue("@image", data)
        Cmd.Parameters.AddWithValue("@desc", txt_description.Text)
        With Cmd
            .Connection = Conn
            .CommandText = sql
        End With
        Cmd.ExecuteNonQuery()
        Cmd.Parameters.Clear()
        CommandDispose()
        Disconnect()
        frm_slideshowedit.lstvw_items.Items.Clear()
        MsgBox("Image Saved", vbOKOnly + vbInformation, "Success")
        Call frm_slideshowedit.frm_slideshowedit_Load(sender, e)
        Me.Close()
    End Sub
End Class