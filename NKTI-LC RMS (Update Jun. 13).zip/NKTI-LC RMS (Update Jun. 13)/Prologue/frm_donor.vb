﻿'Not that you need to install the MySQL connectorfor Visual Studio before you run these scripts
'Also, the WAMP with the MySQL file already uploaded
'Imported cryptography service for hashing the password (One way Encryption)
Imports System.Security.Cryptography
Public Class frm_donor

    Private Sub lbl_close_Click(sender As Object, e As EventArgs) Handles lbl_close.Click
        frm_main.Show()
        Me.TopMost = False
        frm_main.TopMost = True
        frm_main.tmr_slideshow.Enabled = True
        Me.Close()
    End Sub

    Private Sub lbl_close_MouseMove(sender As Object, e As EventArgs) Handles lbl_close.MouseMove
        lbl_close.BackColor = Color.White
    End Sub

    Private Sub lbl_close_mouseleave(sender As Object, e As EventArgs) Handles lbl_close.MouseLeave
        lbl_close.BackColor = Color.DarkCyan
    End Sub

    Private Sub chk_verify_CheckedChanged(sender As Object, e As EventArgs) Handles chk_verify.CheckedChanged
        If chk_verify.Checked Then
            btn_submit.Enabled = True
        Else
            btn_submit.Enabled = False
        End If
    End Sub

    Private Sub frm_donor_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        btn_submit.Enabled = False
    End Sub

    Private Sub btn_submit_Click(sender As Object, e As EventArgs) Handles btn_submit.Click
        Connect()

        Dim sql As String = "INSERT INTO tbl_donor (donorID, Surname, Firstname, Middlename, Age, Birthdate, Gender, Address, CivilStatus, BloodType, Nationality, ContactNo) VALUES ('" & txt_donorID.Text & "','" & txt_surname.Text & "','" & txt_firstname.Text & "','" & txt_middlename.Text & "','" & txt_age.Text & "','" & Convert.ToString(cmb_month.Text) & "-" & Convert.ToString(cmb_date.Text) & "-" & Convert.ToString(cmb_year.Text) & "','" & txt_gender.Text & "','" & txt_address.Text & "','" & cmb_civil.Text & "','" & cmb_bloodtype.Text & "','" & txt_nationality.Text & "','" & txt_contactNO.Text & "')"

        With Cmd
            .Connection = Conn
            .CommandText = sql
        End With

        Try
            rd = Cmd.ExecuteReader
            MsgBox("Insertion of Data Successful!", vbInformation + vbOKOnly, "NOTICE")
        Catch ex As MySql.Data.MySqlClient.MySqlException
            MsgBox(ex.Message)
        Finally
            ReaderDispose()
            CommandDispose()
            Disconnect()
            Call lbl_close_Click(sender, e)
        End Try
    End Sub

    Private Sub rb_male_CheckedChanged(sender As Object, e As EventArgs) Handles rb_male.CheckedChanged
        If rb_male.Checked Then
            txt_gender.Text = rb_male.Text
        End If
    End Sub

    Private Sub rb_female_CheckedChanged(sender As Object, e As EventArgs) Handles rb_female.CheckedChanged
        If rb_female.Checked Then
            txt_gender.Text = rb_female.Text
        End If
    End Sub
End Class