﻿Imports System.IO
Public Class frm_slideshowedit

    Private Sub lbl_close_Click(sender As Object, e As EventArgs) Handles lbl_close.Click
        'Close Button at the Upper-right corner
        frm_main.Show()
        Me.Close()
    End Sub

    'The MouseMove and MouseLeave events are only for design purpose
    Private Sub lbl_close_MouseMove(sender As Object, e As MouseEventArgs) Handles lbl_close.MouseMove
        lbl_close.BackColor = Color.White
    End Sub

    Private Sub lbl_close_MouseLeave(sender As Object, e As EventArgs) Handles lbl_close.MouseLeave
        lbl_close.BackColor = Color.DarkCyan
    End Sub


    Private Sub btn_add_MouseMove(sender As Object, e As EventArgs) Handles btn_add.MouseMove
        lbl_description.Text = "Add new photo with its description."
    End Sub

    Private Sub btn_add_MouseLeave(sender As Object, e As EventArgs) Handles btn_add.MouseLeave
        lbl_description.Text = "Welcome to Slideshow Editor panel."
    End Sub

    Private Sub frm_slideshowedit_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lbl_description.Text = "Welcome to Slideshow Editor panel."
        lstvw_items.View = View.Details
        lstvw_items.FullRowSelect = True
        lstvw_items.AllowColumnReorder = False
        lstvw_items.GridLines = True
        lstvw_items.MultiSelect = False
        lstvw_items.Columns.Add("Item No.", 75, HorizontalAlignment.Right)
        lstvw_items.Columns.Add("Desciption", lstvw_items.Width - 75, HorizontalAlignment.Center)
        pcbx_preview.SizeMode = PictureBoxSizeMode.StretchImage
        btn_update.Enabled = False
        btn_delete.Enabled = False
    End Sub

    Private Sub btn_update_MouseLeave(sender As Object, e As EventArgs) Handles btn_update.MouseLeave
        lbl_description.Text = "Welcome to Slideshow Editor panel."
    End Sub

    Private Sub btn_update_MouseMove(sender As Object, e As EventArgs) Handles btn_update.MouseMove
        lbl_description.Text = "Update image and/or description of the selected item."
    End Sub

    Private Sub btn_delete_MouseMove(sender As Object, e As EventArgs) Handles btn_delete.MouseMove
        lbl_description.Text = "Delete the selected item."
    End Sub

    Private Sub btn_delete_MouseLeave(sender As Object, e As EventArgs) Handles btn_delete.MouseLeave
        lbl_description.Text = "Welcome to Slideshow Editor panel."
    End Sub

    Private Sub btn_add_Click(sender As Object, e As EventArgs) Handles btn_add.Click
        frm_addeditslideshow.Show()
    End Sub

    Public Sub frm_slideshowedit_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sql As String
        sql = "SELECT * FROM tbl_slideshow"

        Connect()

        With Cmd
            .Connection = Conn
            .CommandText = sql
        End With

        rd = Cmd.ExecuteReader

        If rd.HasRows Then
            While rd.Read
                Dim item As New ListViewItem
                With item
                    .Text = rd.GetValue(0)
                    .SubItems.Add(rd.GetValue(2))
                End With
                lstvw_items.Items.Add(item)
            End While
        End If
        ReaderDispose()
        CommandDispose()
        Disconnect()

    End Sub

    Private Sub lstvw_items_Click(sender As Object, e As EventArgs) Handles lstvw_items.Click
        Dim item As ListViewItem = lstvw_items.SelectedItems(0)
        Dim sql As String

        sql = "SELECT * FROM tbl_slideshow WHERE entryNO = '" & item.SubItems(0).Text & "'"

        Connect()
        With Cmd
            .Connection = Conn
            .CommandText = sql
        End With

        rd = Cmd.ExecuteReader

        rd.Read()

        Dim data As Byte() = DirectCast(rd.GetValue(1), Byte())
        Dim ms As New MemoryStream(data)
        pcbx_preview.Image = New Bitmap(ms)
        ReaderDispose()
        CommandDispose()
        Disconnect()
        btn_update.Enabled = True
        btn_delete.Enabled = True
    End Sub

    Private Sub lstvw_items_ItemSelectionChanged(sender As Object, e As ListViewItemSelectionChangedEventArgs) Handles lstvw_items.ItemSelectionChanged
        If lstvw_items.SelectedItems.Count = 0 Then
            btn_update.Enabled = False
            btn_delete.Enabled = False
        End If
    End Sub

    Private Sub btn_update_Click(sender As Object, e As EventArgs) Handles btn_update.Click
        frm_editslideshow.Show()
        Dim item As ListViewItem = lstvw_items.SelectedItems(0)
        Dim sql As String
        sql = "SELECT * FROM tbl_slideshow WHERE entryNo = '" & item.SubItems(0).Text & "'"

        Connect()

        With Cmd
            .Connection = Conn
            .CommandText = sql
        End With

        rd = Cmd.ExecuteReader
        rd.Read()

        frm_editslideshow.txt_imagepath.Text = rd.GetValue(2)
        frm_editslideshow.txt_description.Text = rd.GetValue(2)
        Dim data As Byte() = DirectCast(rd.GetValue(1), Byte())
        Dim ms As New MemoryStream(data)
        frm_editslideshow.pcbx_preview.Image = New Bitmap(ms)
        ReaderDispose()
        CommandDispose()
        Disconnect()
    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click
        Dim msg As String
        msg = MsgBox("Are you that you want to delete the selected item?", vbExclamation + vbYesNo, "Confirmation")
        If msg = vbYes Then
            Dim item As ListViewItem = lstvw_items.SelectedItems(0)
            Dim sql As String

            sql = "DELETE FROM tbl_slideshow WHERE entryNO = '" & item.SubItems(0).Text & "'"

            Connect()
            With Cmd
                .Connection = Conn
                .CommandText = sql
            End With

            Try
                Cmd.ExecuteNonQuery()
                MsgBox("Deletion successfully done.", vbInformation + vbOKOnly, "Success")
            Catch ex As MySql.Data.MySqlClient.MySqlException
                MsgBox(ex.Message)
            Finally
                lstvw_items.Items.Clear()
                ReaderDispose()
                CommandDispose()
                Disconnect()
                btn_delete.Enabled = False
                btn_update.Enabled = False
                Call frm_slideshowedit_Load(sender, e)
            End Try
        End If
    End Sub
End Class