﻿Public Class Encryption
    'my very own JMCrypt 1.0 One way Encryption method
    Function getJMCRYPTHash(ByVal strToHash As String) As String
        Dim str As Integer
        Dim bin As String
        Dim c As Integer
        Dim strresult As String = ""
        bin = ""

        For c = 0 To strToHash.Length - 1
            str = Asc(strToHash(c))
            bin = Convert.ToString(str, 2).PadLeft(8, "0"c)
            strresult += StrReverse(Hex(Convert.ToInt32(bin)))
        Next
        Return strresult
    End Function

    'This function will perform the hashing operation for the password
    Function getSHA1Hash(ByVal strToHash As String) As String
        Dim sha1Obj As New Security.Cryptography.SHA1CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.UTF8.GetBytes(strToHash)

        bytesToHash = sha1Obj.ComputeHash(bytesToHash)

        Dim strResult As String = ""

        For Each b As Byte In bytesToHash
            strResult += b.ToString("x2")
        Next

        Return strResult
    End Function
End Class
