﻿Imports System.IO
Public Class frm_operations

    Private Sub lbl_close_Click(sender As Object, e As EventArgs) Handles lbl_close.Click
        'Close Button at the Upper-right corner
        frm_main.Show()
        Me.Close()
    End Sub

    'The MouseMove and MouseLeave events are only for design purpose
    Private Sub lbl_close_MouseMove(sender As Object, e As MouseEventArgs) Handles lbl_close.MouseMove
        lbl_close.BackColor = Color.White
    End Sub

    Private Sub lbl_close_MouseLeave(sender As Object, e As EventArgs) Handles lbl_close.MouseLeave
        lbl_close.BackColor = Color.DarkCyan
    End Sub

    Private Sub frm_operations_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lbl_description.Text = "Welcome! This is the Center's Operations Log."
        lstvw_operationslog.View = View.Details
        lstvw_operationslog.Columns.Add("Entry No.", 75)
        lstvw_operationslog.Columns.Add("Date", 100)
        lstvw_operationslog.Columns.Add("Details", lstvw_operationslog.Width - (75 + 100))
    End Sub

    Private Sub btn_submit_MouseMove(sender As Object, e As MouseEventArgs) Handles btn_submit.MouseMove
        lbl_description.Text = "Submit the created log to the database."
    End Sub

    Private Sub btn_submit_MouseLeave(sender As Object, e As EventArgs) Handles btn_submit.MouseLeave
        lbl_description.Text = "Welcome! This is the Center's Operations Log."
    End Sub

    Private Sub btn_update_MouseMove(sender As Object, e As MouseEventArgs) Handles btn_update.MouseMove
        lbl_description.Text = "Edit the currently selected for correction."
    End Sub

    Private Sub btn_update_MouseLeave(sender As Object, e As EventArgs) Handles btn_update.MouseLeave
        lbl_description.Text = "Welcome! This is the Center's Operations Log."
    End Sub
    
    Private Sub frm_operations_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sql As String
        sql = "SELECT * FROM tbl_operations"

        Connect()

        With Cmd
            .Connection = Conn
            .CommandText = sql
        End With

        rd = Cmd.ExecuteReader

        If rd.HasRows Then
            While rd.Read
                Dim nwitem As New ListViewItem
                nwitem.Text = rd.GetValue(0)
                nwitem.SubItems.Add(rd.GetValue(1))
                nwitem.SubItems.Add(rd.GetValue(2))
                lstvw_operationslog.Items.Add(nwitem)
            End While
        End If

        ReaderDispose()
        CommandDispose()
        Disconnect()
    End Sub
    
End Class