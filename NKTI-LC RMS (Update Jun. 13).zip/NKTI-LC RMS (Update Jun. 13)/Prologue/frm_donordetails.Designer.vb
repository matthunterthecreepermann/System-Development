﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_donordetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lbl_close = New System.Windows.Forms.Label()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.tmr_transition = New System.Windows.Forms.Timer(Me.components)
        Me.tmr_transition2 = New System.Windows.Forms.Timer(Me.components)
        Me.tmr_load = New System.Windows.Forms.Timer(Me.components)
        Me.gb_donorID = New System.Windows.Forms.GroupBox()
        Me.txt_donorID = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cmb_bloodtype = New System.Windows.Forms.ComboBox()
        Me.gb_civil = New System.Windows.Forms.GroupBox()
        Me.cmb_civil = New System.Windows.Forms.ComboBox()
        Me.gb_contactNO = New System.Windows.Forms.GroupBox()
        Me.txt_contactNO = New System.Windows.Forms.TextBox()
        Me.gb_nationality = New System.Windows.Forms.GroupBox()
        Me.txt_nationality = New System.Windows.Forms.TextBox()
        Me.gb_address = New System.Windows.Forms.GroupBox()
        Me.txt_address = New System.Windows.Forms.TextBox()
        Me.lbl_address = New System.Windows.Forms.Label()
        Me.txt_gender = New System.Windows.Forms.TextBox()
        Me.gb_birthdate = New System.Windows.Forms.GroupBox()
        Me.gb_gender = New System.Windows.Forms.GroupBox()
        Me.rb_female = New System.Windows.Forms.RadioButton()
        Me.rb_male = New System.Windows.Forms.RadioButton()
        Me.gb_age = New System.Windows.Forms.GroupBox()
        Me.txt_age = New System.Windows.Forms.TextBox()
        Me.gb_name = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_middlename = New System.Windows.Forms.TextBox()
        Me.txt_firstname = New System.Windows.Forms.TextBox()
        Me.txt_surname = New System.Windows.Forms.TextBox()
        Me.txt_birthdate = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout()
        Me.gb_donorID.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.gb_civil.SuspendLayout()
        Me.gb_contactNO.SuspendLayout()
        Me.gb_nationality.SuspendLayout()
        Me.gb_address.SuspendLayout()
        Me.gb_birthdate.SuspendLayout()
        Me.gb_gender.SuspendLayout()
        Me.gb_age.SuspendLayout()
        Me.gb_name.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkCyan
        Me.Panel1.Controls.Add(Me.lbl_close)
        Me.Panel1.Controls.Add(Me.lbl_title)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(421, 27)
        Me.Panel1.TabIndex = 2
        '
        'lbl_close
        '
        Me.lbl_close.AutoSize = True
        Me.lbl_close.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_close.ForeColor = System.Drawing.Color.Red
        Me.lbl_close.Location = New System.Drawing.Point(391, -2)
        Me.lbl_close.Name = "lbl_close"
        Me.lbl_close.Size = New System.Drawing.Size(27, 29)
        Me.lbl_close.TabIndex = 7
        Me.lbl_close.Text = "×"
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.ForeColor = System.Drawing.Color.White
        Me.lbl_title.Location = New System.Drawing.Point(8, 4)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(57, 18)
        Me.lbl_title.TabIndex = 1
        Me.lbl_title.Text = "Details"
        '
        'tmr_transition
        '
        Me.tmr_transition.Interval = 1
        '
        'tmr_transition2
        '
        Me.tmr_transition2.Interval = 1
        '
        'tmr_load
        '
        Me.tmr_load.Interval = 10
        '
        'gb_donorID
        '
        Me.gb_donorID.Controls.Add(Me.txt_donorID)
        Me.gb_donorID.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_donorID.ForeColor = System.Drawing.Color.White
        Me.gb_donorID.Location = New System.Drawing.Point(9, 292)
        Me.gb_donorID.Name = "gb_donorID"
        Me.gb_donorID.Size = New System.Drawing.Size(117, 50)
        Me.gb_donorID.TabIndex = 60
        Me.gb_donorID.TabStop = False
        Me.gb_donorID.Text = "DONOR ID"
        '
        'txt_donorID
        '
        Me.txt_donorID.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_donorID.Location = New System.Drawing.Point(6, 18)
        Me.txt_donorID.Name = "txt_donorID"
        Me.txt_donorID.Size = New System.Drawing.Size(105, 26)
        Me.txt_donorID.TabIndex = 10
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmb_bloodtype)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(276, 292)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(128, 50)
        Me.GroupBox1.TabIndex = 59
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "BLOOD TYPE"
        '
        'cmb_bloodtype
        '
        Me.cmb_bloodtype.FormattingEnabled = True
        Me.cmb_bloodtype.Items.AddRange(New Object() {"Type A", "Type B", "Type AB", "Type O", "Unspecified"})
        Me.cmb_bloodtype.Location = New System.Drawing.Point(9, 18)
        Me.cmb_bloodtype.Name = "cmb_bloodtype"
        Me.cmb_bloodtype.Size = New System.Drawing.Size(113, 26)
        Me.cmb_bloodtype.TabIndex = 3
        '
        'gb_civil
        '
        Me.gb_civil.Controls.Add(Me.cmb_civil)
        Me.gb_civil.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_civil.ForeColor = System.Drawing.Color.White
        Me.gb_civil.Location = New System.Drawing.Point(131, 292)
        Me.gb_civil.Name = "gb_civil"
        Me.gb_civil.Size = New System.Drawing.Size(139, 50)
        Me.gb_civil.TabIndex = 58
        Me.gb_civil.TabStop = False
        Me.gb_civil.Text = "CIVIL STATUS"
        '
        'cmb_civil
        '
        Me.cmb_civil.FormattingEnabled = True
        Me.cmb_civil.Items.AddRange(New Object() {"Single", "Married", "Widow", "Others, please type in here..."})
        Me.cmb_civil.Location = New System.Drawing.Point(6, 18)
        Me.cmb_civil.Name = "cmb_civil"
        Me.cmb_civil.Size = New System.Drawing.Size(127, 26)
        Me.cmb_civil.TabIndex = 3
        '
        'gb_contactNO
        '
        Me.gb_contactNO.Controls.Add(Me.txt_contactNO)
        Me.gb_contactNO.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_contactNO.ForeColor = System.Drawing.Color.White
        Me.gb_contactNO.Location = New System.Drawing.Point(160, 348)
        Me.gb_contactNO.Name = "gb_contactNO"
        Me.gb_contactNO.Size = New System.Drawing.Size(244, 63)
        Me.gb_contactNO.TabIndex = 57
        Me.gb_contactNO.TabStop = False
        Me.gb_contactNO.Text = "CONTACT NO/s"
        '
        'txt_contactNO
        '
        Me.txt_contactNO.Location = New System.Drawing.Point(6, 24)
        Me.txt_contactNO.Name = "txt_contactNO"
        Me.txt_contactNO.Size = New System.Drawing.Size(232, 26)
        Me.txt_contactNO.TabIndex = 3
        '
        'gb_nationality
        '
        Me.gb_nationality.Controls.Add(Me.txt_nationality)
        Me.gb_nationality.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_nationality.ForeColor = System.Drawing.Color.White
        Me.gb_nationality.Location = New System.Drawing.Point(11, 347)
        Me.gb_nationality.Name = "gb_nationality"
        Me.gb_nationality.Size = New System.Drawing.Size(143, 64)
        Me.gb_nationality.TabIndex = 56
        Me.gb_nationality.TabStop = False
        Me.gb_nationality.Text = "NATIONALITY"
        '
        'txt_nationality
        '
        Me.txt_nationality.Location = New System.Drawing.Point(6, 25)
        Me.txt_nationality.Name = "txt_nationality"
        Me.txt_nationality.Size = New System.Drawing.Size(131, 26)
        Me.txt_nationality.TabIndex = 1
        '
        'gb_address
        '
        Me.gb_address.Controls.Add(Me.txt_address)
        Me.gb_address.Controls.Add(Me.lbl_address)
        Me.gb_address.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_address.ForeColor = System.Drawing.Color.White
        Me.gb_address.Location = New System.Drawing.Point(11, 204)
        Me.gb_address.Name = "gb_address"
        Me.gb_address.Size = New System.Drawing.Size(393, 81)
        Me.gb_address.TabIndex = 55
        Me.gb_address.TabStop = False
        Me.gb_address.Text = "HOME ADDRESS"
        '
        'txt_address
        '
        Me.txt_address.Location = New System.Drawing.Point(6, 24)
        Me.txt_address.Name = "txt_address"
        Me.txt_address.Size = New System.Drawing.Size(381, 26)
        Me.txt_address.TabIndex = 3
        '
        'lbl_address
        '
        Me.lbl_address.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_address.Location = New System.Drawing.Point(17, 42)
        Me.lbl_address.Name = "lbl_address"
        Me.lbl_address.Size = New System.Drawing.Size(360, 37)
        Me.lbl_address.TabIndex = 2
        Me.lbl_address.Text = "House no. or Blk/Street or Sitio/Brgy./Municipality/Province or City"
        Me.lbl_address.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_gender
        '
        Me.txt_gender.Location = New System.Drawing.Point(285, 191)
        Me.txt_gender.Name = "txt_gender"
        Me.txt_gender.Size = New System.Drawing.Size(100, 20)
        Me.txt_gender.TabIndex = 54
        Me.txt_gender.Text = "Not Defined"
        Me.txt_gender.Visible = False
        '
        'gb_birthdate
        '
        Me.gb_birthdate.Controls.Add(Me.txt_birthdate)
        Me.gb_birthdate.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_birthdate.ForeColor = System.Drawing.Color.White
        Me.gb_birthdate.Location = New System.Drawing.Point(82, 124)
        Me.gb_birthdate.Name = "gb_birthdate"
        Me.gb_birthdate.Size = New System.Drawing.Size(181, 62)
        Me.gb_birthdate.TabIndex = 53
        Me.gb_birthdate.TabStop = False
        Me.gb_birthdate.Text = "BIRTHDATE"
        '
        'gb_gender
        '
        Me.gb_gender.Controls.Add(Me.rb_female)
        Me.gb_gender.Controls.Add(Me.rb_male)
        Me.gb_gender.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_gender.ForeColor = System.Drawing.Color.White
        Me.gb_gender.Location = New System.Drawing.Point(269, 124)
        Me.gb_gender.Name = "gb_gender"
        Me.gb_gender.Size = New System.Drawing.Size(135, 74)
        Me.gb_gender.TabIndex = 52
        Me.gb_gender.TabStop = False
        Me.gb_gender.Text = "GENDER"
        '
        'rb_female
        '
        Me.rb_female.AutoSize = True
        Me.rb_female.Location = New System.Drawing.Point(25, 46)
        Me.rb_female.Name = "rb_female"
        Me.rb_female.Size = New System.Drawing.Size(79, 22)
        Me.rb_female.TabIndex = 1
        Me.rb_female.TabStop = True
        Me.rb_female.Text = "Female"
        Me.rb_female.UseVisualStyleBackColor = True
        '
        'rb_male
        '
        Me.rb_male.AutoSize = True
        Me.rb_male.Location = New System.Drawing.Point(25, 22)
        Me.rb_male.Name = "rb_male"
        Me.rb_male.Size = New System.Drawing.Size(60, 22)
        Me.rb_male.TabIndex = 0
        Me.rb_male.TabStop = True
        Me.rb_male.Text = "Male"
        Me.rb_male.UseVisualStyleBackColor = True
        '
        'gb_age
        '
        Me.gb_age.Controls.Add(Me.txt_age)
        Me.gb_age.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_age.ForeColor = System.Drawing.Color.White
        Me.gb_age.Location = New System.Drawing.Point(11, 124)
        Me.gb_age.Name = "gb_age"
        Me.gb_age.Size = New System.Drawing.Size(65, 62)
        Me.gb_age.TabIndex = 51
        Me.gb_age.TabStop = False
        Me.gb_age.Text = "AGE"
        '
        'txt_age
        '
        Me.txt_age.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_age.Location = New System.Drawing.Point(5, 25)
        Me.txt_age.Name = "txt_age"
        Me.txt_age.Size = New System.Drawing.Size(54, 26)
        Me.txt_age.TabIndex = 9
        '
        'gb_name
        '
        Me.gb_name.Controls.Add(Me.Label3)
        Me.gb_name.Controls.Add(Me.Label2)
        Me.gb_name.Controls.Add(Me.Label1)
        Me.gb_name.Controls.Add(Me.txt_middlename)
        Me.gb_name.Controls.Add(Me.txt_firstname)
        Me.gb_name.Controls.Add(Me.txt_surname)
        Me.gb_name.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_name.ForeColor = System.Drawing.Color.White
        Me.gb_name.Location = New System.Drawing.Point(11, 42)
        Me.gb_name.Name = "gb_name"
        Me.gb_name.Size = New System.Drawing.Size(393, 76)
        Me.gb_name.TabIndex = 50
        Me.gb_name.TabStop = False
        Me.gb_name.Text = "NAME"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(282, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 17)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Middle name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(158, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 17)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "First name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(33, 54)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 17)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Surname"
        '
        'txt_middlename
        '
        Me.txt_middlename.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_middlename.Location = New System.Drawing.Point(265, 25)
        Me.txt_middlename.Name = "txt_middlename"
        Me.txt_middlename.Size = New System.Drawing.Size(124, 26)
        Me.txt_middlename.TabIndex = 11
        '
        'txt_firstname
        '
        Me.txt_firstname.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_firstname.Location = New System.Drawing.Point(135, 25)
        Me.txt_firstname.Name = "txt_firstname"
        Me.txt_firstname.Size = New System.Drawing.Size(124, 26)
        Me.txt_firstname.TabIndex = 10
        '
        'txt_surname
        '
        Me.txt_surname.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_surname.Location = New System.Drawing.Point(5, 25)
        Me.txt_surname.Name = "txt_surname"
        Me.txt_surname.Size = New System.Drawing.Size(124, 26)
        Me.txt_surname.TabIndex = 9
        '
        'txt_birthdate
        '
        Me.txt_birthdate.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_birthdate.Location = New System.Drawing.Point(6, 25)
        Me.txt_birthdate.Name = "txt_birthdate"
        Me.txt_birthdate.Size = New System.Drawing.Size(169, 26)
        Me.txt_birthdate.TabIndex = 11
        '
        'frm_donordetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(419, 479)
        Me.Controls.Add(Me.gb_donorID)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.gb_civil)
        Me.Controls.Add(Me.gb_contactNO)
        Me.Controls.Add(Me.gb_nationality)
        Me.Controls.Add(Me.gb_address)
        Me.Controls.Add(Me.txt_gender)
        Me.Controls.Add(Me.gb_birthdate)
        Me.Controls.Add(Me.gb_gender)
        Me.Controls.Add(Me.gb_age)
        Me.Controls.Add(Me.gb_name)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_donordetails"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.gb_donorID.ResumeLayout(False)
        Me.gb_donorID.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.gb_civil.ResumeLayout(False)
        Me.gb_contactNO.ResumeLayout(False)
        Me.gb_contactNO.PerformLayout()
        Me.gb_nationality.ResumeLayout(False)
        Me.gb_nationality.PerformLayout()
        Me.gb_address.ResumeLayout(False)
        Me.gb_address.PerformLayout()
        Me.gb_birthdate.ResumeLayout(False)
        Me.gb_birthdate.PerformLayout()
        Me.gb_gender.ResumeLayout(False)
        Me.gb_gender.PerformLayout()
        Me.gb_age.ResumeLayout(False)
        Me.gb_age.PerformLayout()
        Me.gb_name.ResumeLayout(False)
        Me.gb_name.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lbl_close As System.Windows.Forms.Label
    Friend WithEvents lbl_title As System.Windows.Forms.Label
    Friend WithEvents tmr_transition As Timer
    Friend WithEvents tmr_transition2 As Timer
    Friend WithEvents tmr_load As System.Windows.Forms.Timer
    Friend WithEvents gb_donorID As System.Windows.Forms.GroupBox
    Friend WithEvents txt_donorID As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmb_bloodtype As System.Windows.Forms.ComboBox
    Friend WithEvents gb_civil As System.Windows.Forms.GroupBox
    Friend WithEvents cmb_civil As System.Windows.Forms.ComboBox
    Friend WithEvents gb_contactNO As System.Windows.Forms.GroupBox
    Friend WithEvents txt_contactNO As System.Windows.Forms.TextBox
    Friend WithEvents gb_nationality As System.Windows.Forms.GroupBox
    Friend WithEvents txt_nationality As System.Windows.Forms.TextBox
    Friend WithEvents gb_address As System.Windows.Forms.GroupBox
    Friend WithEvents txt_address As System.Windows.Forms.TextBox
    Friend WithEvents lbl_address As System.Windows.Forms.Label
    Friend WithEvents txt_gender As System.Windows.Forms.TextBox
    Friend WithEvents gb_birthdate As System.Windows.Forms.GroupBox
    Friend WithEvents gb_gender As System.Windows.Forms.GroupBox
    Friend WithEvents rb_female As System.Windows.Forms.RadioButton
    Friend WithEvents rb_male As System.Windows.Forms.RadioButton
    Friend WithEvents gb_age As System.Windows.Forms.GroupBox
    Friend WithEvents txt_age As System.Windows.Forms.TextBox
    Friend WithEvents gb_name As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_middlename As System.Windows.Forms.TextBox
    Friend WithEvents txt_firstname As System.Windows.Forms.TextBox
    Friend WithEvents txt_surname As System.Windows.Forms.TextBox
    Friend WithEvents txt_birthdate As System.Windows.Forms.TextBox
End Class
