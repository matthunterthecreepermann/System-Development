﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_addeditslideshow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnl_titlebar = New System.Windows.Forms.Panel()
        Me.lbl_close = New System.Windows.Forms.Label()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.txt_imagepath = New System.Windows.Forms.TextBox()
        Me.txt_description = New System.Windows.Forms.TextBox()
        Me.btn_save = New System.Windows.Forms.Button()
        Me.lbl_user = New System.Windows.Forms.Label()
        Me.lbl_pass = New System.Windows.Forms.Label()
        Me.btn_browse = New System.Windows.Forms.Button()
        Me.pcbx_preview = New System.Windows.Forms.PictureBox()
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.pnl_titlebar.SuspendLayout()
        CType(Me.pcbx_preview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnl_titlebar
        '
        Me.pnl_titlebar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnl_titlebar.BackColor = System.Drawing.Color.DarkCyan
        Me.pnl_titlebar.Controls.Add(Me.lbl_close)
        Me.pnl_titlebar.Controls.Add(Me.lbl_title)
        Me.pnl_titlebar.Location = New System.Drawing.Point(0, 0)
        Me.pnl_titlebar.Name = "pnl_titlebar"
        Me.pnl_titlebar.Size = New System.Drawing.Size(292, 27)
        Me.pnl_titlebar.TabIndex = 2
        '
        'lbl_close
        '
        Me.lbl_close.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_close.AutoSize = True
        Me.lbl_close.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_close.ForeColor = System.Drawing.Color.Red
        Me.lbl_close.Location = New System.Drawing.Point(261, -2)
        Me.lbl_close.Name = "lbl_close"
        Me.lbl_close.Size = New System.Drawing.Size(27, 29)
        Me.lbl_close.TabIndex = 7
        Me.lbl_close.Text = "×"
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.ForeColor = System.Drawing.Color.White
        Me.lbl_title.Location = New System.Drawing.Point(8, 4)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(127, 18)
        Me.lbl_title.TabIndex = 1
        Me.lbl_title.Text = "Slideshow Image"
        '
        'txt_imagepath
        '
        Me.txt_imagepath.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_imagepath.Location = New System.Drawing.Point(28, 88)
        Me.txt_imagepath.Name = "txt_imagepath"
        Me.txt_imagepath.Size = New System.Drawing.Size(143, 32)
        Me.txt_imagepath.TabIndex = 3
        '
        'txt_description
        '
        Me.txt_description.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_description.Location = New System.Drawing.Point(28, 159)
        Me.txt_description.Name = "txt_description"
        Me.txt_description.Size = New System.Drawing.Size(231, 32)
        Me.txt_description.TabIndex = 4
        '
        'btn_save
        '
        Me.btn_save.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_save.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.btn_save.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_save.FlatAppearance.BorderSize = 0
        Me.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_save.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_save.ForeColor = System.Drawing.Color.White
        Me.btn_save.Location = New System.Drawing.Point(95, 319)
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Size = New System.Drawing.Size(95, 45)
        Me.btn_save.TabIndex = 5
        Me.btn_save.Text = "Save"
        Me.btn_save.UseVisualStyleBackColor = False
        '
        'lbl_user
        '
        Me.lbl_user.AutoSize = True
        Me.lbl_user.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_user.ForeColor = System.Drawing.Color.White
        Me.lbl_user.Location = New System.Drawing.Point(24, 64)
        Me.lbl_user.Name = "lbl_user"
        Me.lbl_user.Size = New System.Drawing.Size(160, 21)
        Me.lbl_user.TabIndex = 8
        Me.lbl_user.Text = "Image/Imagepath"
        '
        'lbl_pass
        '
        Me.lbl_pass.AutoSize = True
        Me.lbl_pass.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pass.ForeColor = System.Drawing.Color.White
        Me.lbl_pass.Location = New System.Drawing.Point(24, 135)
        Me.lbl_pass.Name = "lbl_pass"
        Me.lbl_pass.Size = New System.Drawing.Size(97, 21)
        Me.lbl_pass.TabIndex = 9
        Me.lbl_pass.Text = "Description"
        '
        'btn_browse
        '
        Me.btn_browse.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_browse.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_browse.FlatAppearance.BorderSize = 0
        Me.btn_browse.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_browse.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_browse.ForeColor = System.Drawing.Color.White
        Me.btn_browse.Location = New System.Drawing.Point(177, 89)
        Me.btn_browse.Name = "btn_browse"
        Me.btn_browse.Size = New System.Drawing.Size(82, 32)
        Me.btn_browse.TabIndex = 10
        Me.btn_browse.Text = "Browse"
        Me.btn_browse.UseVisualStyleBackColor = False
        '
        'pcbx_preview
        '
        Me.pcbx_preview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pcbx_preview.Location = New System.Drawing.Point(28, 197)
        Me.pcbx_preview.Name = "pcbx_preview"
        Me.pcbx_preview.Size = New System.Drawing.Size(231, 116)
        Me.pcbx_preview.TabIndex = 11
        Me.pcbx_preview.TabStop = False
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.FileName = "OpenFileDialog"
        '
        'frm_addeditslideshow
        '
        Me.AcceptButton = Me.btn_save
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(287, 376)
        Me.Controls.Add(Me.pcbx_preview)
        Me.Controls.Add(Me.btn_browse)
        Me.Controls.Add(Me.lbl_pass)
        Me.Controls.Add(Me.lbl_user)
        Me.Controls.Add(Me.btn_save)
        Me.Controls.Add(Me.txt_description)
        Me.Controls.Add(Me.txt_imagepath)
        Me.Controls.Add(Me.pnl_titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_addeditslideshow"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        Me.pnl_titlebar.ResumeLayout(False)
        Me.pnl_titlebar.PerformLayout()
        CType(Me.pcbx_preview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnl_titlebar As System.Windows.Forms.Panel
    Friend WithEvents lbl_close As System.Windows.Forms.Label
    Friend WithEvents lbl_title As System.Windows.Forms.Label
    Friend WithEvents txt_imagepath As System.Windows.Forms.TextBox
    Friend WithEvents txt_description As System.Windows.Forms.TextBox
    Friend WithEvents btn_save As System.Windows.Forms.Button
    Friend WithEvents lbl_user As System.Windows.Forms.Label
    Friend WithEvents lbl_pass As System.Windows.Forms.Label
    Friend WithEvents btn_browse As System.Windows.Forms.Button
    Friend WithEvents pcbx_preview As System.Windows.Forms.PictureBox
    Friend WithEvents OpenFileDialog As System.Windows.Forms.OpenFileDialog
End Class
