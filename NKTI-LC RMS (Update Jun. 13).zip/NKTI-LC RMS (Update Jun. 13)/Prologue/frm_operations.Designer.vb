﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_operations
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnl_titlebar = New System.Windows.Forms.Panel()
        Me.lbl_close = New System.Windows.Forms.Label()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.lbl_description = New System.Windows.Forms.Label()
        Me.gb_items = New System.Windows.Forms.GroupBox()
        Me.lstvw_operationslog = New System.Windows.Forms.ListView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btn_update = New System.Windows.Forms.Button()
        Me.btn_submit = New System.Windows.Forms.Button()
        Me.txt_entry = New System.Windows.Forms.TextBox()
        Me.pnl_titlebar.SuspendLayout()
        Me.gb_items.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnl_titlebar
        '
        Me.pnl_titlebar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnl_titlebar.BackColor = System.Drawing.Color.DarkCyan
        Me.pnl_titlebar.Controls.Add(Me.lbl_close)
        Me.pnl_titlebar.Controls.Add(Me.lbl_title)
        Me.pnl_titlebar.Location = New System.Drawing.Point(0, 0)
        Me.pnl_titlebar.Name = "pnl_titlebar"
        Me.pnl_titlebar.Size = New System.Drawing.Size(602, 27)
        Me.pnl_titlebar.TabIndex = 2
        '
        'lbl_close
        '
        Me.lbl_close.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_close.AutoSize = True
        Me.lbl_close.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_close.ForeColor = System.Drawing.Color.Red
        Me.lbl_close.Location = New System.Drawing.Point(571, -2)
        Me.lbl_close.Name = "lbl_close"
        Me.lbl_close.Size = New System.Drawing.Size(27, 29)
        Me.lbl_close.TabIndex = 7
        Me.lbl_close.Text = "×"
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.ForeColor = System.Drawing.Color.White
        Me.lbl_title.Location = New System.Drawing.Point(8, 4)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(116, 18)
        Me.lbl_title.TabIndex = 1
        Me.lbl_title.Text = "Operations Log"
        '
        'lbl_description
        '
        Me.lbl_description.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_description.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_description.ForeColor = System.Drawing.Color.White
        Me.lbl_description.Location = New System.Drawing.Point(11, 305)
        Me.lbl_description.Name = "lbl_description"
        Me.lbl_description.Size = New System.Drawing.Size(574, 23)
        Me.lbl_description.TabIndex = 5
        '
        'gb_items
        '
        Me.gb_items.Controls.Add(Me.lstvw_operationslog)
        Me.gb_items.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_items.ForeColor = System.Drawing.Color.White
        Me.gb_items.Location = New System.Drawing.Point(19, 45)
        Me.gb_items.Name = "gb_items"
        Me.gb_items.Size = New System.Drawing.Size(559, 186)
        Me.gb_items.TabIndex = 11
        Me.gb_items.TabStop = False
        Me.gb_items.Text = "ITEMS"
        '
        'lstvw_operationslog
        '
        Me.lstvw_operationslog.Location = New System.Drawing.Point(17, 33)
        Me.lstvw_operationslog.Name = "lstvw_operationslog"
        Me.lstvw_operationslog.Size = New System.Drawing.Size(526, 138)
        Me.lstvw_operationslog.TabIndex = 11
        Me.lstvw_operationslog.UseCompatibleStateImageBehavior = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btn_update)
        Me.GroupBox1.Controls.Add(Me.btn_submit)
        Me.GroupBox1.Controls.Add(Me.txt_entry)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(19, 237)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(559, 56)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "ENTRY AND UPDATE"
        '
        'btn_update
        '
        Me.btn_update.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_update.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_update.FlatAppearance.BorderSize = 0
        Me.btn_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_update.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_update.ForeColor = System.Drawing.Color.White
        Me.btn_update.Location = New System.Drawing.Point(472, 19)
        Me.btn_update.Name = "btn_update"
        Me.btn_update.Size = New System.Drawing.Size(76, 29)
        Me.btn_update.TabIndex = 16
        Me.btn_update.Text = "Update"
        Me.btn_update.UseVisualStyleBackColor = False
        '
        'btn_submit
        '
        Me.btn_submit.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.btn_submit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_submit.FlatAppearance.BorderSize = 0
        Me.btn_submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_submit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_submit.ForeColor = System.Drawing.Color.White
        Me.btn_submit.Location = New System.Drawing.Point(390, 19)
        Me.btn_submit.Name = "btn_submit"
        Me.btn_submit.Size = New System.Drawing.Size(76, 29)
        Me.btn_submit.TabIndex = 15
        Me.btn_submit.Text = "Submit"
        Me.btn_submit.UseVisualStyleBackColor = False
        '
        'txt_entry
        '
        Me.txt_entry.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_entry.Location = New System.Drawing.Point(9, 21)
        Me.txt_entry.Name = "txt_entry"
        Me.txt_entry.Size = New System.Drawing.Size(375, 26)
        Me.txt_entry.TabIndex = 14
        '
        'frm_operations
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(597, 329)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.gb_items)
        Me.Controls.Add(Me.lbl_description)
        Me.Controls.Add(Me.pnl_titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_operations"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        Me.pnl_titlebar.ResumeLayout(False)
        Me.pnl_titlebar.PerformLayout()
        Me.gb_items.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnl_titlebar As System.Windows.Forms.Panel
    Friend WithEvents lbl_close As System.Windows.Forms.Label
    Friend WithEvents lbl_title As System.Windows.Forms.Label
    Friend WithEvents lbl_description As System.Windows.Forms.Label
    Friend WithEvents gb_items As System.Windows.Forms.GroupBox
    Friend WithEvents lstvw_operationslog As System.Windows.Forms.ListView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_update As System.Windows.Forms.Button
    Friend WithEvents btn_submit As System.Windows.Forms.Button
    Friend WithEvents txt_entry As System.Windows.Forms.TextBox
End Class
