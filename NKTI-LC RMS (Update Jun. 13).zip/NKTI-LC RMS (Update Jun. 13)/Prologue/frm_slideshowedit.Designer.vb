﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_slideshowedit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnl_titlebar = New System.Windows.Forms.Panel()
        Me.lbl_close = New System.Windows.Forms.Label()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.pcbx_preview = New System.Windows.Forms.PictureBox()
        Me.lstvw_items = New System.Windows.Forms.ListView()
        Me.lbl_description = New System.Windows.Forms.Label()
        Me.gb_frame = New System.Windows.Forms.GroupBox()
        Me.btn_delete = New System.Windows.Forms.Button()
        Me.btn_update = New System.Windows.Forms.Button()
        Me.btn_add = New System.Windows.Forms.Button()
        Me.pnl_titlebar.SuspendLayout()
        CType(Me.pcbx_preview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_frame.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnl_titlebar
        '
        Me.pnl_titlebar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnl_titlebar.BackColor = System.Drawing.Color.DarkCyan
        Me.pnl_titlebar.Controls.Add(Me.lbl_close)
        Me.pnl_titlebar.Controls.Add(Me.lbl_title)
        Me.pnl_titlebar.Location = New System.Drawing.Point(0, 0)
        Me.pnl_titlebar.Name = "pnl_titlebar"
        Me.pnl_titlebar.Size = New System.Drawing.Size(602, 27)
        Me.pnl_titlebar.TabIndex = 2
        '
        'lbl_close
        '
        Me.lbl_close.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_close.AutoSize = True
        Me.lbl_close.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_close.ForeColor = System.Drawing.Color.Red
        Me.lbl_close.Location = New System.Drawing.Point(571, -2)
        Me.lbl_close.Name = "lbl_close"
        Me.lbl_close.Size = New System.Drawing.Size(27, 29)
        Me.lbl_close.TabIndex = 7
        Me.lbl_close.Text = "×"
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.ForeColor = System.Drawing.Color.White
        Me.lbl_title.Location = New System.Drawing.Point(8, 4)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(289, 18)
        Me.lbl_title.TabIndex = 1
        Me.lbl_title.Text = "Add or Update Slideshow on Main Panel"
        '
        'pcbx_preview
        '
        Me.pcbx_preview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pcbx_preview.Location = New System.Drawing.Point(12, 43)
        Me.pcbx_preview.Name = "pcbx_preview"
        Me.pcbx_preview.Size = New System.Drawing.Size(285, 233)
        Me.pcbx_preview.TabIndex = 3
        Me.pcbx_preview.TabStop = False
        '
        'lstvw_items
        '
        Me.lstvw_items.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstvw_items.Location = New System.Drawing.Point(304, 43)
        Me.lstvw_items.Name = "lstvw_items"
        Me.lstvw_items.Size = New System.Drawing.Size(281, 156)
        Me.lstvw_items.TabIndex = 4
        Me.lstvw_items.UseCompatibleStateImageBehavior = False
        '
        'lbl_description
        '
        Me.lbl_description.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_description.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_description.ForeColor = System.Drawing.Color.White
        Me.lbl_description.Location = New System.Drawing.Point(11, 305)
        Me.lbl_description.Name = "lbl_description"
        Me.lbl_description.Size = New System.Drawing.Size(574, 23)
        Me.lbl_description.TabIndex = 5
        '
        'gb_frame
        '
        Me.gb_frame.Controls.Add(Me.btn_delete)
        Me.gb_frame.Controls.Add(Me.btn_update)
        Me.gb_frame.Controls.Add(Me.btn_add)
        Me.gb_frame.Location = New System.Drawing.Point(303, 205)
        Me.gb_frame.Name = "gb_frame"
        Me.gb_frame.Size = New System.Drawing.Size(281, 71)
        Me.gb_frame.TabIndex = 9
        Me.gb_frame.TabStop = False
        '
        'btn_delete
        '
        Me.btn_delete.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(57, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.btn_delete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_delete.FlatAppearance.BorderSize = 0
        Me.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_delete.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_delete.ForeColor = System.Drawing.Color.White
        Me.btn_delete.Location = New System.Drawing.Point(189, 16)
        Me.btn_delete.Name = "btn_delete"
        Me.btn_delete.Size = New System.Drawing.Size(86, 45)
        Me.btn_delete.TabIndex = 11
        Me.btn_delete.Text = "Delete"
        Me.btn_delete.UseVisualStyleBackColor = False
        '
        'btn_update
        '
        Me.btn_update.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_update.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_update.FlatAppearance.BorderSize = 0
        Me.btn_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_update.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_update.ForeColor = System.Drawing.Color.White
        Me.btn_update.Location = New System.Drawing.Point(98, 16)
        Me.btn_update.Name = "btn_update"
        Me.btn_update.Size = New System.Drawing.Size(86, 45)
        Me.btn_update.TabIndex = 10
        Me.btn_update.Text = "Update"
        Me.btn_update.UseVisualStyleBackColor = False
        '
        'btn_add
        '
        Me.btn_add.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.btn_add.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_add.FlatAppearance.BorderSize = 0
        Me.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_add.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_add.ForeColor = System.Drawing.Color.White
        Me.btn_add.Location = New System.Drawing.Point(7, 16)
        Me.btn_add.Name = "btn_add"
        Me.btn_add.Size = New System.Drawing.Size(86, 45)
        Me.btn_add.TabIndex = 9
        Me.btn_add.Text = "Add"
        Me.btn_add.UseVisualStyleBackColor = False
        '
        'frm_slideshowedit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(597, 329)
        Me.Controls.Add(Me.gb_frame)
        Me.Controls.Add(Me.lbl_description)
        Me.Controls.Add(Me.lstvw_items)
        Me.Controls.Add(Me.pcbx_preview)
        Me.Controls.Add(Me.pnl_titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_slideshowedit"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        Me.pnl_titlebar.ResumeLayout(False)
        Me.pnl_titlebar.PerformLayout()
        CType(Me.pcbx_preview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_frame.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnl_titlebar As System.Windows.Forms.Panel
    Friend WithEvents lbl_close As System.Windows.Forms.Label
    Friend WithEvents lbl_title As System.Windows.Forms.Label
    Friend WithEvents pcbx_preview As System.Windows.Forms.PictureBox
    Friend WithEvents lstvw_items As System.Windows.Forms.ListView
    Friend WithEvents lbl_description As System.Windows.Forms.Label
    Friend WithEvents gb_frame As System.Windows.Forms.GroupBox
    Friend WithEvents btn_delete As System.Windows.Forms.Button
    Friend WithEvents btn_update As System.Windows.Forms.Button
    Friend WithEvents btn_add As System.Windows.Forms.Button
End Class
