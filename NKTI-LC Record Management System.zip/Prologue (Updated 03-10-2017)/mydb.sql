-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2017 at 08:26 PM
-- Server version: 5.7.9
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--
CREATE DATABASE IF NOT EXISTS `mydb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `mydb`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

DROP TABLE IF EXISTS `tbl_login`;
CREATE TABLE IF NOT EXISTS `tbl_login` (
  `user` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `privilege` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`user`, `pass`, `privilege`) VALUES
('matthunter', '2cae1552948a2f8a335b9b2102e5aba847663cce', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_records`
--

DROP TABLE IF EXISTS `tbl_records`;
CREATE TABLE IF NOT EXISTS `tbl_records` (
  `patientID` varchar(250) CHARACTER SET utf8 NOT NULL,
  `lastname` varchar(50) CHARACTER SET utf8 NOT NULL,
  `firstname` varchar(50) CHARACTER SET utf16 NOT NULL,
  `middlename` varchar(50) CHARACTER SET utf8 NOT NULL,
  `birthdate` varchar(20) CHARACTER SET utf8 NOT NULL,
  `age` varchar(200) CHARACTER SET utf8 NOT NULL,
  `gender` varchar(10) CHARACTER SET utf8 NOT NULL,
  `hospNO` varchar(250) CHARACTER SET utf8 NOT NULL,
  `civil` varchar(10) CHARACTER SET utf8 NOT NULL,
  `nationality` varchar(20) CHARACTER SET utf8 NOT NULL,
  `address` longtext CHARACTER SET utf8 NOT NULL,
  `religion` varchar(50) CHARACTER SET utf8 NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `contactNO` varchar(20) CHARACTER SET utf8 NOT NULL,
  `referral` longtext CHARACTER SET utf8 NOT NULL,
  `emergency_name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `emergency_relation` varchar(50) CHARACTER SET utf8 NOT NULL,
  `emergency_address` longtext CHARACTER SET utf8 NOT NULL,
  `emergency_contactNO` varchar(20) CHARACTER SET utf8 NOT NULL,
  `occupation` varchar(50) CHARACTER SET utf32 NOT NULL,
  `company` varchar(100) CHARACTER SET utf8 NOT NULL,
  `office_contactNO` varchar(20) CHARACTER SET utf8 NOT NULL,
  `office_address` varchar(100) NOT NULL,
  `personalmedhist` varchar(100) CHARACTER SET utf8 NOT NULL,
  `familymedhist` varchar(100) CHARACTER SET utf8 NOT NULL,
  `surgical_operation` varchar(200) CHARACTER SET utf8 NOT NULL,
  `date_performed` varchar(20) CHARACTER SET utf32 NOT NULL,
  PRIMARY KEY (`patientID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_records`
--

INSERT INTO `tbl_records` (`patientID`, `lastname`, `firstname`, `middlename`, `birthdate`, `age`, `gender`, `hospNO`, `civil`, `nationality`, `address`, `religion`, `email`, `contactNO`, `referral`, `emergency_name`, `emergency_relation`, `emergency_address`, `emergency_contactNO`, `occupation`, `company`, `office_contactNO`, `office_address`, `personalmedhist`, `familymedhist`, `surgical_operation`, `date_performed`) VALUES
('10001', 'MARALIT', 'JAIME JR', 'VILLANUEVA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
