﻿Module MySQLDBConn
    'Declaration of needed variable
    Public Conn As New MySql.Data.MySqlClient.MySqlConnection
    Public Cmd As New MySql.Data.MySqlClient.MySqlCommand
    Public rd As MySql.Data.MySqlClient.MySqlDataReader

    'Function for establishing Connection to the Database
    Public Sub Connect()
        'Reading Configuration file
        Dim File_Name As String = "..\..\Config\Conn_String.txt"
        Dim ObjReader As New System.IO.StreamReader(File_Name)
        Dim ConnString As String = ""

        'Assigning variable to the content of config file
        ConnString = ObjReader.ReadToEnd

        'Assigning connection string from ConnString Variable
        Conn.ConnectionString = ConnString

        'Opening Connection
        Conn.Open()
    End Sub

    'Function for disconnecting on Database
    Public Sub Disconnect()
        Conn.Close()
    End Sub

    'Function to dispose the reader variable
    Public Sub ReaderDispose()
        rd.Dispose()
    End Sub

    'Function to dispose the command variable
    Public Sub CommandDispose()
        Cmd.Dispose()
    End Sub
End Module
