﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_configDB
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lbl_close = New System.Windows.Forms.Label()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.gb_server = New System.Windows.Forms.GroupBox()
        Me.txt_server = New System.Windows.Forms.TextBox()
        Me.gb_user = New System.Windows.Forms.GroupBox()
        Me.txt_user = New System.Windows.Forms.TextBox()
        Me.gb_pass = New System.Windows.Forms.GroupBox()
        Me.txt_pass = New System.Windows.Forms.TextBox()
        Me.gb_database = New System.Windows.Forms.GroupBox()
        Me.txt_database = New System.Windows.Forms.TextBox()
        Me.gb_port = New System.Windows.Forms.GroupBox()
        Me.txt_port = New System.Windows.Forms.TextBox()
        Me.btn_submit = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.gb_server.SuspendLayout()
        Me.gb_user.SuspendLayout()
        Me.gb_pass.SuspendLayout()
        Me.gb_database.SuspendLayout()
        Me.gb_port.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.DarkCyan
        Me.Panel1.Controls.Add(Me.lbl_close)
        Me.Panel1.Controls.Add(Me.lbl_title)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(289, 27)
        Me.Panel1.TabIndex = 3
        '
        'lbl_close
        '
        Me.lbl_close.AutoSize = True
        Me.lbl_close.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_close.ForeColor = System.Drawing.Color.Red
        Me.lbl_close.Location = New System.Drawing.Point(258, -2)
        Me.lbl_close.Name = "lbl_close"
        Me.lbl_close.Size = New System.Drawing.Size(27, 29)
        Me.lbl_close.TabIndex = 7
        Me.lbl_close.Text = "×"
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.ForeColor = System.Drawing.Color.White
        Me.lbl_title.Location = New System.Drawing.Point(8, 4)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(186, 18)
        Me.lbl_title.TabIndex = 1
        Me.lbl_title.Text = "Configure DB Connection"
        '
        'gb_server
        '
        Me.gb_server.Controls.Add(Me.txt_server)
        Me.gb_server.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_server.ForeColor = System.Drawing.Color.White
        Me.gb_server.Location = New System.Drawing.Point(26, 55)
        Me.gb_server.Name = "gb_server"
        Me.gb_server.Size = New System.Drawing.Size(232, 65)
        Me.gb_server.TabIndex = 11
        Me.gb_server.TabStop = False
        Me.gb_server.Text = "SERVER NAME"
        '
        'txt_server
        '
        Me.txt_server.Location = New System.Drawing.Point(6, 25)
        Me.txt_server.Name = "txt_server"
        Me.txt_server.Size = New System.Drawing.Size(220, 26)
        Me.txt_server.TabIndex = 1
        Me.txt_server.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gb_user
        '
        Me.gb_user.Controls.Add(Me.txt_user)
        Me.gb_user.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_user.ForeColor = System.Drawing.Color.White
        Me.gb_user.Location = New System.Drawing.Point(26, 126)
        Me.gb_user.Name = "gb_user"
        Me.gb_user.Size = New System.Drawing.Size(232, 65)
        Me.gb_user.TabIndex = 12
        Me.gb_user.TabStop = False
        Me.gb_user.Text = "USERNAME"
        '
        'txt_user
        '
        Me.txt_user.Location = New System.Drawing.Point(6, 25)
        Me.txt_user.Name = "txt_user"
        Me.txt_user.Size = New System.Drawing.Size(220, 26)
        Me.txt_user.TabIndex = 1
        Me.txt_user.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gb_pass
        '
        Me.gb_pass.Controls.Add(Me.txt_pass)
        Me.gb_pass.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_pass.ForeColor = System.Drawing.Color.White
        Me.gb_pass.Location = New System.Drawing.Point(25, 197)
        Me.gb_pass.Name = "gb_pass"
        Me.gb_pass.Size = New System.Drawing.Size(232, 65)
        Me.gb_pass.TabIndex = 13
        Me.gb_pass.TabStop = False
        Me.gb_pass.Text = "PASSWORD"
        '
        'txt_pass
        '
        Me.txt_pass.Location = New System.Drawing.Point(6, 25)
        Me.txt_pass.Name = "txt_pass"
        Me.txt_pass.Size = New System.Drawing.Size(220, 26)
        Me.txt_pass.TabIndex = 1
        Me.txt_pass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gb_database
        '
        Me.gb_database.Controls.Add(Me.txt_database)
        Me.gb_database.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_database.ForeColor = System.Drawing.Color.White
        Me.gb_database.Location = New System.Drawing.Point(25, 275)
        Me.gb_database.Name = "gb_database"
        Me.gb_database.Size = New System.Drawing.Size(232, 65)
        Me.gb_database.TabIndex = 14
        Me.gb_database.TabStop = False
        Me.gb_database.Text = "DATABASE"
        '
        'txt_database
        '
        Me.txt_database.Location = New System.Drawing.Point(6, 25)
        Me.txt_database.Name = "txt_database"
        Me.txt_database.Size = New System.Drawing.Size(220, 26)
        Me.txt_database.TabIndex = 1
        Me.txt_database.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gb_port
        '
        Me.gb_port.Controls.Add(Me.txt_port)
        Me.gb_port.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_port.ForeColor = System.Drawing.Color.White
        Me.gb_port.Location = New System.Drawing.Point(26, 346)
        Me.gb_port.Name = "gb_port"
        Me.gb_port.Size = New System.Drawing.Size(232, 65)
        Me.gb_port.TabIndex = 15
        Me.gb_port.TabStop = False
        Me.gb_port.Text = "PORT NUMBER"
        '
        'txt_port
        '
        Me.txt_port.Location = New System.Drawing.Point(6, 25)
        Me.txt_port.Name = "txt_port"
        Me.txt_port.Size = New System.Drawing.Size(220, 26)
        Me.txt_port.TabIndex = 1
        Me.txt_port.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_submit
        '
        Me.btn_submit.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_submit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_submit.FlatAppearance.BorderSize = 0
        Me.btn_submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_submit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_submit.ForeColor = System.Drawing.Color.White
        Me.btn_submit.Location = New System.Drawing.Point(93, 423)
        Me.btn_submit.Name = "btn_submit"
        Me.btn_submit.Size = New System.Drawing.Size(95, 45)
        Me.btn_submit.TabIndex = 16
        Me.btn_submit.Text = "SUBMIT"
        Me.btn_submit.UseVisualStyleBackColor = False
        '
        'frm_configDB
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(283, 481)
        Me.Controls.Add(Me.btn_submit)
        Me.Controls.Add(Me.gb_port)
        Me.Controls.Add(Me.gb_database)
        Me.Controls.Add(Me.gb_pass)
        Me.Controls.Add(Me.gb_user)
        Me.Controls.Add(Me.gb_server)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_configDB"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.gb_server.ResumeLayout(False)
        Me.gb_server.PerformLayout()
        Me.gb_user.ResumeLayout(False)
        Me.gb_user.PerformLayout()
        Me.gb_pass.ResumeLayout(False)
        Me.gb_pass.PerformLayout()
        Me.gb_database.ResumeLayout(False)
        Me.gb_database.PerformLayout()
        Me.gb_port.ResumeLayout(False)
        Me.gb_port.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lbl_close As System.Windows.Forms.Label
    Friend WithEvents lbl_title As System.Windows.Forms.Label
    Friend WithEvents gb_server As System.Windows.Forms.GroupBox
    Friend WithEvents txt_server As System.Windows.Forms.TextBox
    Friend WithEvents gb_user As System.Windows.Forms.GroupBox
    Friend WithEvents txt_user As System.Windows.Forms.TextBox
    Friend WithEvents gb_pass As System.Windows.Forms.GroupBox
    Friend WithEvents txt_pass As System.Windows.Forms.TextBox
    Friend WithEvents gb_database As System.Windows.Forms.GroupBox
    Friend WithEvents txt_database As System.Windows.Forms.TextBox
    Friend WithEvents gb_port As System.Windows.Forms.GroupBox
    Friend WithEvents txt_port As System.Windows.Forms.TextBox
    Friend WithEvents btn_submit As System.Windows.Forms.Button
End Class
