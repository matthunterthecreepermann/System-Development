﻿Public Class frm_main

    Private Sub lbl_close_Click(sender As Object, e As EventArgs) Handles lbl_close.Click
        Dim x As String
        x = MsgBox("Are you sure that you want to log-out?", vbExclamation + vbYesNo, "Confirmation")
        If x = vbYes Then
            ss_status.Visible = False
            tmr_transition2.Enabled = True
            wait(1)
            Me.Close()
            tmr_transition.Enabled = True
            frm_login.txt_user.Text = ""
            frm_login.txt_pass.Text = ""
            frm_login.Show()
            frm_login.txt_user.Focus()
        Else
            Exit Sub
        End If
    End Sub

    Private Sub Label2_MouseMove(sender As Object, e As MouseEventArgs) Handles lbl_close.MouseMove
        lbl_close.BackColor = Color.White
    End Sub

    Private Sub Label2_MouseLeave(sender As Object, e As EventArgs) Handles lbl_close.MouseLeave
        lbl_close.BackColor = Color.DarkCyan
    End Sub

    Private Sub tmr_transition_Tick(sender As Object, e As EventArgs) Handles tmr_transition.Tick
        If frm_login.Height <> 300 Then
            frm_login.Height = frm_login.Height + 10
        Else
            tmr_transition.Enabled = False
        End If
    End Sub
    Private Sub wait(ByVal seconds As Integer)
        For i As Integer = 0 To seconds * 100
            System.Threading.Thread.Sleep(10)
            Application.DoEvents()
        Next
    End Sub

    Private Sub tmr_transition2_Tick(sender As Object, e As EventArgs) Handles tmr_transition2.Tick
        If Me.Height <> 30 Then
            Me.Height = Me.Height - 10
        Else
            tmr_transition2.Enabled = False
        End If
    End Sub

    Private Sub frm_main_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        pnl_registration.Visible = False
        pnl_status.Visible = False
    End Sub

    
    Private Sub btn_registration_Click(sender As Object, e As EventArgs) Handles btn_registration.Click
        tran_buttons.HideSync(pnl_main, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_registration, True, BunifuAnimatorNS.Animation.HorizSlide)
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles btn_home.Click
        tran_buttons.HideSync(pnl_registration, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_main, True, BunifuAnimatorNS.Animation.HorizSlide)
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem1.Click
        Call lbl_close_Click(sender, e)
    End Sub

    Private Sub btn_status_Click(sender As Object, e As EventArgs) Handles btn_status.Click
        'This two first lines are for transitioning buttons 
        tran_buttons.HideSync(pnl_home, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_status, True, BunifuAnimatorNS.Animation.HorizSlide)

        'This line is for clearing the listview object and refreshes for new items
        lstvw_status.Clear()

        lstvw_status.Columns.Add("Patient ID", 100, HorizontalAlignment.Right)
        lstvw_status.Columns.Add("Surname", 150, HorizontalAlignment.Center)
        lstvw_status.Columns.Add("First Name", 150, HorizontalAlignment.Center)
        lstvw_status.Columns.Add("Last Name", 150, HorizontalAlignment.Center)

        'Declaring variable for query on DB
        Dim query As String

        'Establishes connection
        Connect()

        'Assigning value to the query variable
        query = "SELECT * FROM tbl_records"

        'Assigning connection and query to the command object
        With Cmd
            .Connection = Conn
            .CommandText = query
        End With

        'Execute Reader
        rd = Cmd.ExecuteReader

        'If there's a content, will show some of the details
        If rd.HasRows Then
            While rd.Read
                Dim nw_item As New ListViewItem
                nw_item.Text = rd.GetValue(0)
                nw_item.SubItems.Add(rd.GetValue(1))
                nw_item.SubItems.Add(rd.GetValue(2))
                nw_item.SubItems.Add(rd.GetValue(3))
                lstvw_status.Items.Add(nw_item)
                If nw_item.Text = "10001" Then
                    nw_item.BackColor = Color.Black
                    nw_item.ForeColor = Color.White
                End If
            End While
        End If
        ReaderDispose()
        CommandDispose()
        Disconnect()
    End Sub

    Private Sub pnl_status_VisibleChanged(sender As Object, e As EventArgs) Handles pnl_status.VisibleChanged
    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        tran_buttons.HideSync(pnl_status, True, BunifuAnimatorNS.Animation.HorizSlide)
        tran_buttons.ShowSync(pnl_home, True, BunifuAnimatorNS.Animation.HorizSlide)
    End Sub

    Private Sub btn_drop_MouseMove(sender As Object, e As MouseEventArgs) Handles btn_drop.MouseMove
        cms_drop.Show(btn_drop, btn_drop.Width - cms_drop.Width, btn_drop.Height)
    End Sub
End Class
