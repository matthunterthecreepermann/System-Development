﻿Public Class frm_recipient
 
    Private Sub chk_verify_CheckedChanged(sender As Object, e As EventArgs) Handles chk_verify.CheckedChanged
        If chk_verify.Checked Then
            btn_submit.Enabled = True
        Else
            btn_submit.Enabled = False
        End If
    End Sub

    Private Sub frm_recipient_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        btn_submit.Enabled = False
    End Sub

    Private Sub btn_submit_Click(sender As Object, e As EventArgs) Handles btn_submit.Click
        Dim conn As New MySql.Data.MySqlClient.MySqlConnection
        Dim connstring As String = ""
        Dim FileNameConfig As String = "..\..\Config\Conn_String.txt"
        Dim sr As New System.IO.StreamReader(FileNameConfig)
        Dim rd As MySql.Data.MySqlClient.MySqlDataReader
        Dim cmd As New MySql.Data.MySqlClient.MySqlCommand
        Dim query As String
        connstring = sr.ReadToEnd()

        conn.ConnectionString = connstring
        conn.Open()

        query = "INSERT INTO tbl_records (patientID,lastname,firstname,middlename,birthdate,age,gender,hospNO,civil,nationality,address,religion,email,contactNO,referral,emergency_name,emergency_relation,emergency_address,emergency_contactNO,occupation,company,office_contactNO,office_address,personalmedhist,familymedhist,surgical_operation,date_performed) VALUES ('" & txt_patientID.Text & "','" & txt_surname.Text & "','" & txt_firstname.Text & "','" & txt_middlename.Text & "','" & Convert.ToString(cmb_month.Text) & "-" & Convert.ToString(cmb_date.Text) & "-" & Convert.ToString(cmb_year.Text) & "','" & txt_age.Text & "','" & txt_gender.Text & "','" & txt_hospitalNO.Text & "','" & txt_civil.Text & "','" & txt_nationality.Text & "','" & txt_address.Text & "','" & txt_religion.Text & "','" & txt_email.Text & "','" & txt_contactNO.Text & "','" & txt_referred.Text & "','" & txt_emername.Text & "','" & txt_emerrelationship.Text & "','" & txt_emeraddress.Text & "','" & txt_emercontact.Text & "','" & txt_occupation.Text & "','" & txt_dept.Text & "','" & txt_officecontact.Text & "','" & txt_officeaddress.Text & "','" & cmb_personalmed.Text & "','" & cmb_familymed.Text & "','" & txt_surgical.Text & "','" & txt_dateperformed.Text & "')"

        With cmd
            .Connection = conn
            .CommandText = query
        End With

        Try
            rd = cmd.ExecuteReader
            MsgBox("Insertion of Data Successful!", vbInformation + vbOKOnly, "NOTICE")
        Catch ex As MySql.Data.MySqlClient.MySqlException
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try




    End Sub

    Private Sub rb_male_CheckedChanged(sender As Object, e As EventArgs) Handles rb_male.CheckedChanged
        txt_gender.Text = ""
        If rb_male.Checked Then
            txt_gender.Text = "Male"
        End If
    End Sub

    Private Sub rb_female_CheckedChanged(sender As Object, e As EventArgs) Handles rb_female.CheckedChanged
        txt_gender.Text = ""
        If rb_female.Checked Then
            txt_gender.Text = "Female"
        End If
    End Sub

    Private Sub rb_single_CheckedChanged(sender As Object, e As EventArgs) Handles rb_single.CheckedChanged
        txt_civil.Text = ""
        If rb_single.Checked Then
            txt_civil.Text = "Single"
        End If
    End Sub

    Private Sub rb_married_CheckedChanged(sender As Object, e As EventArgs) Handles rb_married.CheckedChanged
        txt_civil.Text = ""
        If rb_married.Checked Then
            txt_civil.Text = "Married"
        End If
    End Sub

    Private Sub rb_widow_CheckedChanged(sender As Object, e As EventArgs) Handles rb_widow.CheckedChanged
        txt_civil.Text = ""
        If rb_widow.Checked Then
            txt_civil.Text = "Widow"
        End If
    End Sub

    Private Sub rb_others_CheckedChanged(sender As Object, e As EventArgs) Handles rb_others.CheckedChanged
        txt_civil.Text = ""
        If rb_others.Checked Then
            txt_civil.Text = "Others"
        End If
    End Sub

    Private Sub rb_service_CheckedChanged(sender As Object, e As EventArgs) Handles rb_service.CheckedChanged
        txt_class.Text = ""
        If rb_service.Checked Then
            txt_class.Text = "Service"
        End If
    End Sub

    Private Sub rb_pay_CheckedChanged(sender As Object, e As EventArgs) Handles rb_pay.CheckedChanged
        txt_class.Text = ""
        If rb_pay.Checked Then
            txt_class.Text = "Pay"
        End If
    End Sub

    Private Sub rb_nktiemployee_CheckedChanged(sender As Object, e As EventArgs) Handles rb_nktiemployee.CheckedChanged
        txt_company.Text = ""
        If rb_nktiemployee.Checked Then
            txt_company.Text = "NKTI Employee - "
            txt_dept.Enabled = True
        End If

    End Sub

    Private Sub rb_otherdept_CheckedChanged(sender As Object, e As EventArgs) Handles rb_otherdept.CheckedChanged
        txt_company.Text = ""
        If rb_otherdept.Checked Then
            txt_dept.Enabled = True
        End If
    End Sub
End Class