﻿Public Class frm_account


    Private Sub btn_logout_Click(sender As Object, e As EventArgs) Handles btn_logout.Click
        frm_logout_confirmation.Show()
    End Sub
End Class