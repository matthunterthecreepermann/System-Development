﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Animation5 As BunifuAnimatorNS.Animation = New BunifuAnimatorNS.Animation()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_main))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lbl_close = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tmr_transition = New System.Windows.Forms.Timer(Me.components)
        Me.tmr_transition2 = New System.Windows.Forms.Timer(Me.components)
        Me.ms_control = New System.Windows.Forms.MenuStrip()
        Me.ToolStripContainer1 = New System.Windows.Forms.ToolStripContainer()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ss_status = New System.Windows.Forms.StatusStrip()
        Me.tlstrp_User = New System.Windows.Forms.ToolStripStatusLabel()
        Me.pnl_home = New System.Windows.Forms.Panel()
        Me.btn_recipient = New System.Windows.Forms.PictureBox()
        Me.pnl_registration = New System.Windows.Forms.Panel()
        Me.btn_home = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton6 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_donor = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.tran_buttons = New BunifuAnimatorNS.BunifuTransition(Me.components)
        Me.pnl_status = New System.Windows.Forms.Panel()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.lstvw_status = New System.Windows.Forms.ListView()
        Me.btn_drop = New System.Windows.Forms.Button()
        Me.pnl_main = New System.Windows.Forms.Panel()
        Me.BunifuFlatButton4 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton3 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_status = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_registration = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.cms_drop = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ActivityLogToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1.SuspendLayout()
        Me.ToolStripContainer1.TopToolStripPanel.SuspendLayout()
        Me.ToolStripContainer1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ss_status.SuspendLayout()
        Me.pnl_home.SuspendLayout()
        CType(Me.btn_recipient, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_registration.SuspendLayout()
        Me.pnl_status.SuspendLayout()
        Me.pnl_main.SuspendLayout()
        Me.cms_drop.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkCyan
        Me.Panel1.Controls.Add(Me.lbl_close)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.tran_buttons.SetDecoration(Me.Panel1, BunifuAnimatorNS.DecorationType.None)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(802, 27)
        Me.Panel1.TabIndex = 1
        '
        'lbl_close
        '
        Me.tran_buttons.SetDecoration(Me.lbl_close, BunifuAnimatorNS.DecorationType.None)
        Me.lbl_close.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_close.ForeColor = System.Drawing.Color.Red
        Me.lbl_close.Location = New System.Drawing.Point(773, -1)
        Me.lbl_close.Name = "lbl_close"
        Me.lbl_close.Size = New System.Drawing.Size(27, 29)
        Me.lbl_close.TabIndex = 7
        Me.lbl_close.Text = "×"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.tran_buttons.SetDecoration(Me.Label1, BunifuAnimatorNS.DecorationType.None)
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(358, 18)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "NKTI - Liver Center Record Management System©"
        '
        'tmr_transition
        '
        Me.tmr_transition.Interval = 1
        '
        'tmr_transition2
        '
        Me.tmr_transition2.Interval = 1
        '
        'ms_control
        '
        Me.tran_buttons.SetDecoration(Me.ms_control, BunifuAnimatorNS.DecorationType.None)
        Me.ms_control.Dock = System.Windows.Forms.DockStyle.None
        Me.ms_control.Location = New System.Drawing.Point(0, 0)
        Me.ms_control.Name = "ms_control"
        Me.ms_control.Size = New System.Drawing.Size(802, 24)
        Me.ms_control.TabIndex = 12
        Me.ms_control.Text = "MenuStrip1"
        '
        'ToolStripContainer1
        '
        '
        'ToolStripContainer1.BottomToolStripPanel
        '
        Me.tran_buttons.SetDecoration(Me.ToolStripContainer1.BottomToolStripPanel, BunifuAnimatorNS.DecorationType.None)
        '
        'ToolStripContainer1.ContentPanel
        '
        Me.tran_buttons.SetDecoration(Me.ToolStripContainer1.ContentPanel, BunifuAnimatorNS.DecorationType.None)
        Me.ToolStripContainer1.ContentPanel.Size = New System.Drawing.Size(802, 3)
        Me.tran_buttons.SetDecoration(Me.ToolStripContainer1, BunifuAnimatorNS.DecorationType.None)
        '
        'ToolStripContainer1.LeftToolStripPanel
        '
        Me.tran_buttons.SetDecoration(Me.ToolStripContainer1.LeftToolStripPanel, BunifuAnimatorNS.DecorationType.None)
        Me.ToolStripContainer1.Location = New System.Drawing.Point(0, 27)
        Me.ToolStripContainer1.Name = "ToolStripContainer1"
        '
        'ToolStripContainer1.RightToolStripPanel
        '
        Me.tran_buttons.SetDecoration(Me.ToolStripContainer1.RightToolStripPanel, BunifuAnimatorNS.DecorationType.None)
        Me.ToolStripContainer1.Size = New System.Drawing.Size(802, 27)
        Me.ToolStripContainer1.TabIndex = 13
        Me.ToolStripContainer1.Text = "ToolStripContainer1"
        '
        'ToolStripContainer1.TopToolStripPanel
        '
        Me.ToolStripContainer1.TopToolStripPanel.Controls.Add(Me.ms_control)
        Me.tran_buttons.SetDecoration(Me.ToolStripContainer1.TopToolStripPanel, BunifuAnimatorNS.DecorationType.None)
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.tran_buttons.SetDecoration(Me.Panel2, BunifuAnimatorNS.DecorationType.None)
        Me.Panel2.Location = New System.Drawing.Point(11, 60)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(184, 181)
        Me.Panel2.TabIndex = 14
        '
        'PictureBox1
        '
        Me.tran_buttons.SetDecoration(Me.PictureBox1, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox1.Image = Global.Prologue.My.Resources.Resources.liverlogo
        Me.PictureBox1.InitialImage = Nothing
        Me.PictureBox1.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(174, 168)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'ss_status
        '
        Me.ss_status.AutoSize = False
        Me.tran_buttons.SetDecoration(Me.ss_status, BunifuAnimatorNS.DecorationType.None)
        Me.ss_status.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tlstrp_User})
        Me.ss_status.Location = New System.Drawing.Point(0, 562)
        Me.ss_status.Name = "ss_status"
        Me.ss_status.Size = New System.Drawing.Size(800, 38)
        Me.ss_status.TabIndex = 16
        Me.ss_status.Text = "StatusStrip1"
        '
        'tlstrp_User
        '
        Me.tlstrp_User.AutoSize = False
        Me.tlstrp_User.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlstrp_User.ForeColor = System.Drawing.Color.White
        Me.tlstrp_User.Name = "tlstrp_User"
        Me.tlstrp_User.Size = New System.Drawing.Size(350, 33)
        '
        'pnl_home
        '
        Me.pnl_home.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnl_home.Controls.Add(Me.btn_recipient)
        Me.tran_buttons.SetDecoration(Me.pnl_home, BunifuAnimatorNS.DecorationType.None)
        Me.pnl_home.Location = New System.Drawing.Point(201, 60)
        Me.pnl_home.Name = "pnl_home"
        Me.pnl_home.Size = New System.Drawing.Size(587, 499)
        Me.pnl_home.TabIndex = 17
        '
        'btn_recipient
        '
        Me.btn_recipient.BackColor = System.Drawing.Color.Black
        Me.tran_buttons.SetDecoration(Me.btn_recipient, BunifuAnimatorNS.DecorationType.None)
        Me.btn_recipient.Location = New System.Drawing.Point(3, 56)
        Me.btn_recipient.Name = "btn_recipient"
        Me.btn_recipient.Size = New System.Drawing.Size(577, 374)
        Me.btn_recipient.TabIndex = 0
        Me.btn_recipient.TabStop = False
        '
        'pnl_registration
        '
        Me.pnl_registration.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnl_registration.Controls.Add(Me.btn_home)
        Me.pnl_registration.Controls.Add(Me.BunifuFlatButton6)
        Me.pnl_registration.Controls.Add(Me.btn_donor)
        Me.tran_buttons.SetDecoration(Me.pnl_registration, BunifuAnimatorNS.DecorationType.None)
        Me.pnl_registration.Location = New System.Drawing.Point(11, 248)
        Me.pnl_registration.Name = "pnl_registration"
        Me.pnl_registration.Size = New System.Drawing.Size(184, 278)
        Me.pnl_registration.TabIndex = 18
        '
        'btn_home
        '
        Me.btn_home.Activecolor = System.Drawing.Color.DodgerBlue
        Me.btn_home.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_home.BorderRadius = 0
        Me.btn_home.ButtonText = "Home"
        Me.btn_home.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tran_buttons.SetDecoration(Me.btn_home, BunifuAnimatorNS.DecorationType.None)
        Me.btn_home.DisabledColor = System.Drawing.Color.Gray
        Me.btn_home.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_home.Iconimage = Global.Prologue.My.Resources.Resources.home
        Me.btn_home.Iconimage_right = Nothing
        Me.btn_home.Iconimage_right_Selected = Nothing
        Me.btn_home.Iconimage_Selected = Nothing
        Me.btn_home.IconRightVisible = True
        Me.btn_home.IconRightZoom = 0.0R
        Me.btn_home.IconVisible = True
        Me.btn_home.IconZoom = 70.0R
        Me.btn_home.IsTab = False
        Me.btn_home.Location = New System.Drawing.Point(3, 113)
        Me.btn_home.Name = "btn_home"
        Me.btn_home.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_home.OnHovercolor = System.Drawing.Color.SkyBlue
        Me.btn_home.OnHoverTextColor = System.Drawing.Color.Gray
        Me.btn_home.selected = False
        Me.btn_home.Size = New System.Drawing.Size(175, 48)
        Me.btn_home.TabIndex = 2
        Me.btn_home.Text = "Home"
        Me.btn_home.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_home.Textcolor = System.Drawing.Color.White
        Me.btn_home.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton6
        '
        Me.BunifuFlatButton6.Activecolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton6.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton6.BorderRadius = 0
        Me.BunifuFlatButton6.ButtonText = "Recipient"
        Me.BunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tran_buttons.SetDecoration(Me.BunifuFlatButton6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton6.Iconimage = Global.Prologue.My.Resources.Resources.Assessment
        Me.BunifuFlatButton6.Iconimage_right = Nothing
        Me.BunifuFlatButton6.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton6.Iconimage_Selected = Nothing
        Me.BunifuFlatButton6.IconRightVisible = True
        Me.BunifuFlatButton6.IconRightZoom = 0.0R
        Me.BunifuFlatButton6.IconVisible = True
        Me.BunifuFlatButton6.IconZoom = 70.0R
        Me.BunifuFlatButton6.IsTab = False
        Me.BunifuFlatButton6.Location = New System.Drawing.Point(2, 4)
        Me.BunifuFlatButton6.Name = "BunifuFlatButton6"
        Me.BunifuFlatButton6.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton6.OnHovercolor = System.Drawing.Color.SkyBlue
        Me.BunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton6.selected = False
        Me.BunifuFlatButton6.Size = New System.Drawing.Size(175, 48)
        Me.BunifuFlatButton6.TabIndex = 1
        Me.BunifuFlatButton6.Text = "Recipient"
        Me.BunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton6.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton6.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_donor
        '
        Me.btn_donor.Activecolor = System.Drawing.Color.DodgerBlue
        Me.btn_donor.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_donor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_donor.BorderRadius = 0
        Me.btn_donor.ButtonText = "Donor"
        Me.btn_donor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tran_buttons.SetDecoration(Me.btn_donor, BunifuAnimatorNS.DecorationType.None)
        Me.btn_donor.DisabledColor = System.Drawing.Color.Gray
        Me.btn_donor.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_donor.Iconimage = Global.Prologue.My.Resources.Resources.Assessment
        Me.btn_donor.Iconimage_right = Nothing
        Me.btn_donor.Iconimage_right_Selected = Nothing
        Me.btn_donor.Iconimage_Selected = Nothing
        Me.btn_donor.IconRightVisible = True
        Me.btn_donor.IconRightZoom = 0.0R
        Me.btn_donor.IconVisible = True
        Me.btn_donor.IconZoom = 70.0R
        Me.btn_donor.IsTab = False
        Me.btn_donor.Location = New System.Drawing.Point(3, 58)
        Me.btn_donor.Name = "btn_donor"
        Me.btn_donor.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_donor.OnHovercolor = System.Drawing.Color.SkyBlue
        Me.btn_donor.OnHoverTextColor = System.Drawing.Color.Gray
        Me.btn_donor.selected = False
        Me.btn_donor.Size = New System.Drawing.Size(175, 48)
        Me.btn_donor.TabIndex = 0
        Me.btn_donor.Text = "Donor"
        Me.btn_donor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_donor.Textcolor = System.Drawing.Color.White
        Me.btn_donor.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'tran_buttons
        '
        Me.tran_buttons.AnimationType = BunifuAnimatorNS.AnimationType.VertSlide
        Me.tran_buttons.Cursor = Nothing
        Animation5.AnimateOnlyDifferences = True
        Animation5.BlindCoeff = CType(resources.GetObject("Animation5.BlindCoeff"), System.Drawing.PointF)
        Animation5.LeafCoeff = 0.0!
        Animation5.MaxTime = 1.0!
        Animation5.MinTime = 0.0!
        Animation5.MosaicCoeff = CType(resources.GetObject("Animation5.MosaicCoeff"), System.Drawing.PointF)
        Animation5.MosaicShift = CType(resources.GetObject("Animation5.MosaicShift"), System.Drawing.PointF)
        Animation5.MosaicSize = 0
        Animation5.Padding = New System.Windows.Forms.Padding(0)
        Animation5.RotateCoeff = 0.0!
        Animation5.RotateLimit = 0.0!
        Animation5.ScaleCoeff = CType(resources.GetObject("Animation5.ScaleCoeff"), System.Drawing.PointF)
        Animation5.SlideCoeff = CType(resources.GetObject("Animation5.SlideCoeff"), System.Drawing.PointF)
        Animation5.TimeCoeff = 0.0!
        Animation5.TransparencyCoeff = 0.0!
        Me.tran_buttons.DefaultAnimation = Animation5
        '
        'pnl_status
        '
        Me.pnl_status.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnl_status.Controls.Add(Me.btn_back)
        Me.pnl_status.Controls.Add(Me.lstvw_status)
        Me.tran_buttons.SetDecoration(Me.pnl_status, BunifuAnimatorNS.DecorationType.None)
        Me.pnl_status.Location = New System.Drawing.Point(201, 60)
        Me.pnl_status.Name = "pnl_status"
        Me.pnl_status.Size = New System.Drawing.Size(587, 499)
        Me.pnl_status.TabIndex = 19
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_back.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tran_buttons.SetDecoration(Me.btn_back, BunifuAnimatorNS.DecorationType.None)
        Me.btn_back.FlatAppearance.BorderSize = 0
        Me.btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_back.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.ForeColor = System.Drawing.Color.White
        Me.btn_back.Location = New System.Drawing.Point(475, 436)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(95, 45)
        Me.btn_back.TabIndex = 6
        Me.btn_back.Text = "Back"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'lstvw_status
        '
        Me.tran_buttons.SetDecoration(Me.lstvw_status, BunifuAnimatorNS.DecorationType.None)
        Me.lstvw_status.GridLines = True
        Me.lstvw_status.Location = New System.Drawing.Point(14, 15)
        Me.lstvw_status.Name = "lstvw_status"
        Me.lstvw_status.Size = New System.Drawing.Size(556, 231)
        Me.lstvw_status.TabIndex = 0
        Me.lstvw_status.UseCompatibleStateImageBehavior = False
        Me.lstvw_status.View = System.Windows.Forms.View.Details
        '
        'btn_drop
        '
        Me.btn_drop.BackColor = System.Drawing.Color.White
        Me.tran_buttons.SetDecoration(Me.btn_drop, BunifuAnimatorNS.DecorationType.None)
        Me.btn_drop.FlatAppearance.BorderSize = 0
        Me.btn_drop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_drop.Image = Global.Prologue.My.Resources.Resources.Menu
        Me.btn_drop.Location = New System.Drawing.Point(724, 27)
        Me.btn_drop.Name = "btn_drop"
        Me.btn_drop.Size = New System.Drawing.Size(75, 23)
        Me.btn_drop.TabIndex = 22
        Me.btn_drop.UseVisualStyleBackColor = False
        '
        'pnl_main
        '
        Me.pnl_main.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnl_main.Controls.Add(Me.BunifuFlatButton4)
        Me.pnl_main.Controls.Add(Me.BunifuFlatButton3)
        Me.pnl_main.Controls.Add(Me.btn_status)
        Me.pnl_main.Controls.Add(Me.btn_registration)
        Me.tran_buttons.SetDecoration(Me.pnl_main, BunifuAnimatorNS.DecorationType.None)
        Me.pnl_main.Location = New System.Drawing.Point(11, 248)
        Me.pnl_main.Name = "pnl_main"
        Me.pnl_main.Size = New System.Drawing.Size(184, 278)
        Me.pnl_main.TabIndex = 23
        '
        'BunifuFlatButton4
        '
        Me.BunifuFlatButton4.Activecolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton4.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton4.BorderRadius = 0
        Me.BunifuFlatButton4.ButtonText = "Search"
        Me.BunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tran_buttons.SetDecoration(Me.BunifuFlatButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton4.Iconimage = Global.Prologue.My.Resources.Resources.Search
        Me.BunifuFlatButton4.Iconimage_right = Nothing
        Me.BunifuFlatButton4.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton4.Iconimage_Selected = Nothing
        Me.BunifuFlatButton4.IconRightVisible = True
        Me.BunifuFlatButton4.IconRightZoom = 0.0R
        Me.BunifuFlatButton4.IconVisible = True
        Me.BunifuFlatButton4.IconZoom = 80.0R
        Me.BunifuFlatButton4.IsTab = False
        Me.BunifuFlatButton4.Location = New System.Drawing.Point(3, 166)
        Me.BunifuFlatButton4.Name = "BunifuFlatButton4"
        Me.BunifuFlatButton4.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton4.OnHovercolor = System.Drawing.Color.SkyBlue
        Me.BunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton4.selected = False
        Me.BunifuFlatButton4.Size = New System.Drawing.Size(175, 48)
        Me.BunifuFlatButton4.TabIndex = 3
        Me.BunifuFlatButton4.Text = "Search"
        Me.BunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton4.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton4.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton3
        '
        Me.BunifuFlatButton3.Activecolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton3.BackColor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton3.BorderRadius = 0
        Me.BunifuFlatButton3.ButtonText = "Operations"
        Me.BunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tran_buttons.SetDecoration(Me.BunifuFlatButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton3.Iconimage = Global.Prologue.My.Resources.Resources.Operation
        Me.BunifuFlatButton3.Iconimage_right = Nothing
        Me.BunifuFlatButton3.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton3.Iconimage_Selected = Nothing
        Me.BunifuFlatButton3.IconRightVisible = True
        Me.BunifuFlatButton3.IconRightZoom = 0.0R
        Me.BunifuFlatButton3.IconVisible = True
        Me.BunifuFlatButton3.IconZoom = 70.0R
        Me.BunifuFlatButton3.IsTab = False
        Me.BunifuFlatButton3.Location = New System.Drawing.Point(3, 112)
        Me.BunifuFlatButton3.Name = "BunifuFlatButton3"
        Me.BunifuFlatButton3.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.BunifuFlatButton3.OnHovercolor = System.Drawing.Color.SkyBlue
        Me.BunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton3.selected = False
        Me.BunifuFlatButton3.Size = New System.Drawing.Size(175, 48)
        Me.BunifuFlatButton3.TabIndex = 2
        Me.BunifuFlatButton3.Text = "Operations"
        Me.BunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton3.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton3.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_status
        '
        Me.btn_status.Activecolor = System.Drawing.Color.DodgerBlue
        Me.btn_status.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_status.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_status.BorderRadius = 0
        Me.btn_status.ButtonText = "Status"
        Me.btn_status.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tran_buttons.SetDecoration(Me.btn_status, BunifuAnimatorNS.DecorationType.None)
        Me.btn_status.DisabledColor = System.Drawing.Color.Gray
        Me.btn_status.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_status.Iconimage = Global.Prologue.My.Resources.Resources.Eligible
        Me.btn_status.Iconimage_right = Nothing
        Me.btn_status.Iconimage_right_Selected = Nothing
        Me.btn_status.Iconimage_Selected = Nothing
        Me.btn_status.IconRightVisible = True
        Me.btn_status.IconRightZoom = 0.0R
        Me.btn_status.IconVisible = True
        Me.btn_status.IconZoom = 90.0R
        Me.btn_status.IsTab = False
        Me.btn_status.Location = New System.Drawing.Point(3, 58)
        Me.btn_status.Name = "btn_status"
        Me.btn_status.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_status.OnHovercolor = System.Drawing.Color.SkyBlue
        Me.btn_status.OnHoverTextColor = System.Drawing.Color.Gray
        Me.btn_status.selected = False
        Me.btn_status.Size = New System.Drawing.Size(175, 48)
        Me.btn_status.TabIndex = 1
        Me.btn_status.Text = "Status"
        Me.btn_status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_status.Textcolor = System.Drawing.Color.White
        Me.btn_status.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_registration
        '
        Me.btn_registration.Activecolor = System.Drawing.Color.DodgerBlue
        Me.btn_registration.BackColor = System.Drawing.Color.DodgerBlue
        Me.btn_registration.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_registration.BorderRadius = 0
        Me.btn_registration.ButtonText = "Registration"
        Me.btn_registration.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tran_buttons.SetDecoration(Me.btn_registration, BunifuAnimatorNS.DecorationType.None)
        Me.btn_registration.DisabledColor = System.Drawing.Color.Gray
        Me.btn_registration.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_registration.Iconimage = Global.Prologue.My.Resources.Resources.add
        Me.btn_registration.Iconimage_right = Nothing
        Me.btn_registration.Iconimage_right_Selected = Nothing
        Me.btn_registration.Iconimage_Selected = Nothing
        Me.btn_registration.IconRightVisible = True
        Me.btn_registration.IconRightZoom = 0.0R
        Me.btn_registration.IconVisible = True
        Me.btn_registration.IconZoom = 70.0R
        Me.btn_registration.IsTab = False
        Me.btn_registration.Location = New System.Drawing.Point(3, 4)
        Me.btn_registration.Name = "btn_registration"
        Me.btn_registration.Normalcolor = System.Drawing.Color.DodgerBlue
        Me.btn_registration.OnHovercolor = System.Drawing.Color.SkyBlue
        Me.btn_registration.OnHoverTextColor = System.Drawing.Color.Gray
        Me.btn_registration.selected = False
        Me.btn_registration.Size = New System.Drawing.Size(175, 48)
        Me.btn_registration.TabIndex = 0
        Me.btn_registration.Text = "Registration"
        Me.btn_registration.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_registration.Textcolor = System.Drawing.Color.White
        Me.btn_registration.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'cms_drop
        '
        Me.tran_buttons.SetDecoration(Me.cms_drop, BunifuAnimatorNS.DecorationType.None)
        Me.cms_drop.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ActivityLogToolStripMenuItem, Me.LogoutToolStripMenuItem1})
        Me.cms_drop.Name = "cms_drop"
        Me.cms_drop.Size = New System.Drawing.Size(153, 70)
        '
        'ActivityLogToolStripMenuItem
        '
        Me.ActivityLogToolStripMenuItem.Name = "ActivityLogToolStripMenuItem"
        Me.ActivityLogToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.ActivityLogToolStripMenuItem.Text = "Activity Log"
        '
        'LogoutToolStripMenuItem1
        '
        Me.LogoutToolStripMenuItem1.Name = "LogoutToolStripMenuItem1"
        Me.LogoutToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.LogoutToolStripMenuItem1.Text = "Log-out"
        '
        'frm_main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(800, 600)
        Me.Controls.Add(Me.pnl_main)
        Me.Controls.Add(Me.btn_drop)
        Me.Controls.Add(Me.pnl_registration)
        Me.Controls.Add(Me.pnl_status)
        Me.Controls.Add(Me.pnl_home)
        Me.Controls.Add(Me.ss_status)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.ToolStripContainer1)
        Me.Controls.Add(Me.Panel1)
        Me.tran_buttons.SetDecoration(Me, BunifuAnimatorNS.DecorationType.None)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.Name = "frm_main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ToolStripContainer1.TopToolStripPanel.ResumeLayout(False)
        Me.ToolStripContainer1.TopToolStripPanel.PerformLayout()
        Me.ToolStripContainer1.ResumeLayout(False)
        Me.ToolStripContainer1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ss_status.ResumeLayout(False)
        Me.ss_status.PerformLayout()
        Me.pnl_home.ResumeLayout(False)
        CType(Me.btn_recipient, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_registration.ResumeLayout(False)
        Me.pnl_status.ResumeLayout(False)
        Me.pnl_main.ResumeLayout(False)
        Me.cms_drop.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbl_close As System.Windows.Forms.Label
    Friend WithEvents tmr_transition As Timer
    Friend WithEvents tmr_transition2 As Timer
    Friend WithEvents ms_control As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripContainer1 As System.Windows.Forms.ToolStripContainer
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ss_status As System.Windows.Forms.StatusStrip
    Friend WithEvents tlstrp_User As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents pnl_home As System.Windows.Forms.Panel
    Friend WithEvents btn_recipient As System.Windows.Forms.PictureBox
    Friend WithEvents pnl_registration As System.Windows.Forms.Panel
    Friend WithEvents BunifuFlatButton6 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_donor As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents tran_buttons As BunifuAnimatorNS.BunifuTransition
    Friend WithEvents btn_home As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents pnl_status As System.Windows.Forms.Panel
    Friend WithEvents lstvw_status As System.Windows.Forms.ListView
    Friend WithEvents btn_back As System.Windows.Forms.Button
    Friend WithEvents btn_drop As System.Windows.Forms.Button
    Friend WithEvents pnl_main As System.Windows.Forms.Panel
    Friend WithEvents BunifuFlatButton4 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton3 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_status As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_registration As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents cms_drop As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ActivityLogToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
End Class
