﻿Public Class frm_configDB
    
    Private Sub btn_submit_Click(sender As Object, e As EventArgs) Handles btn_submit.Click
        Dim File_Name As System.IO.StreamWriter
        Dim wr As String = ""

        wr = "server=" & txt_server.Text & ";uid=" & txt_user.Text & ";pwd=" & txt_pass.Text & ";database=" & txt_database.Text & ";Port=" & txt_port.Text & ";"
        File_Name = My.Computer.FileSystem.OpenTextFileWriter("..\..\Config\Conn_String.txt", False)

        File_Name.WriteLine(wr)
        File_Name.Close()
        If MsgBox("Successfully configured. Please restart the application.", MsgBoxStyle.Information + vbOKOnly, "Success!") Then
            Me.Close()
            frm_login.Close()
        End If
    End Sub
End Class